import React, { useCallback, useEffect, useRef, useState } from 'react';
import { DialogKind, Dialogs } from './components/Dialogs';
import { FloatingMeters } from './components/FloatingMeters';
import { LeftPalette } from './components/LeftPalette';
import { MenuBar } from './components/MenuBar';
import { PropertiesPanel } from './components/PropertiesPanel';
import { SelectionState, SimulationCanvas } from './components/SimulationCanvas';
import { TapePlayerBar } from './components/TapePlayerBar';
import { TopToolbar } from './components/TopToolbar';
import {
  ActiveDragSpring,
  captureTapeFrame,
  cloneSimulationState,
  restoreTapeFrame,
  sampleBodyMetric,
  stepSimulation,
} from './physics/engine';
import { generateStandaloneHtml } from './physics/exportHtml';
import { recalcBodyMassProperties, vLen, vSub } from './physics/math';
import { loadPreset, nextId } from './physics/presets';
import {
  CameraState,
  ControlWidget,
  MeterDisplayType,
  MeterMetric,
  MeterWidget,
  PhysicsConstraint,
  RigidBody,
  ScriptRule,
  SimulationState,
  TapeFrame,
  TextAnnotation,
  ToolId,
  Vec2,
  WorldSettings,
} from './physics/types';

export default function App() {
  const initialBundle = useRef(loadPreset('pendulum'));
  const simRef = useRef<SimulationState>(cloneSimulationState(initialBundle.current.state));
  const initialResetRef = useRef<SimulationState>(cloneSimulationState(initialBundle.current.state));
  const cameraRef = useRef<CameraState>({ panX: 0, panY: 0, ppm: 55 });
  const dragSpringRef = useRef<ActiveDragSpring | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Undo / Redo & Tape History
  const lastCommittedRef = useRef<SimulationState>(cloneSimulationState(initialBundle.current.state));
  const undoStackRef = useRef<SimulationState[]>([]);
  const redoStackRef = useRef<SimulationState[]>([]);
  const tapeFramesRef = useRef<TapeFrame[]>([captureTapeFrame(simRef.current)]);
  const clipboardRef = useRef<RigidBody[]>([]);

  // React UI state
  const [isRunning, setIsRunning] = useState(false);
  const [activeTool, setActiveTool] = useState<ToolId>('select');
  const [selection, setSelection] = useState<SelectionState>({
    bodyIds: [],
    constraintId: null,
    annotationId: null,
  });
  const [currentPresetId, setCurrentPresetId] = useState('pendulum');
  const [meters, setMeters] = useState<MeterWidget[]>(initialBundle.current.meters);
  const [controls, setControls] = useState<ControlWidget[]>(initialBundle.current.controls);
  const [scripts, setScripts] = useState<ScriptRule[]>([]);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [cursorWorld, setCursorWorld] = useState<Vec2>({ x: 0, y: 0 });
  const [currentTapeIdx, setCurrentTapeIdx] = useState(0);
  const [renderVersion, setRenderVersion] = useState(0);

  // Panel visibility
  const [showPalette, setShowPalette] = useState(true);
  const [showProperties, setShowProperties] = useState(true);
  const [showTape, setShowTape] = useState(true);
  const [activeDialog, setActiveDialog] = useState<DialogKind>(null);

  // In-app text annotation modal (avoids window.prompt in iframe)
  const [pendingTextPos, setPendingTextPos] = useState<Vec2 | null>(null);
  const [pendingTextValue, setPendingTextValue] = useState('');
  const [htmlCodeModal, setHtmlCodeModal] = useState<{ open: boolean; code: string; copied: boolean }>({
    open: false,
    code: '',
    copied: false,
  });

  const handleOpenHtmlCode = useCallback(async () => {
    setHtmlCodeModal({ open: true, code: 'Loading standalone HTML...', copied: false });
    try {
      const res = await fetch('/interactive-physics.html');
      const text = await res.text();
      setHtmlCodeModal({ open: true, code: text, copied: false });
    } catch {
      setHtmlCodeModal({ open: true, code: 'Could not load /interactive-physics.html', copied: false });
    }
  }, []);

  const bumpUI = useCallback(() => {
    setRenderVersion((v) => v + 1);
  }, []);

  const pushUndo = useCallback(() => {
    undoStackRef.current.push(cloneSimulationState(simRef.current));
    if (undoStackRef.current.length > 40) undoStackRef.current.shift();
    redoStackRef.current = [];
  }, []);

  const commitMutation = useCallback(
    (recordUndo = true) => {
      if (recordUndo) {
        undoStackRef.current.push(lastCommittedRef.current);
        if (undoStackRef.current.length > 40) undoStackRef.current.shift();
        redoStackRef.current = [];
        lastCommittedRef.current = cloneSimulationState(simRef.current);
        if (simRef.current.frame === 0) {
          initialResetRef.current = cloneSimulationState(simRef.current);
          tapeFramesRef.current = [captureTapeFrame(simRef.current)];
          setCurrentTapeIdx(0);
        }
      } else {
        lastCommittedRef.current = cloneSimulationState(simRef.current);
      }
      bumpUI();
    },
    [bumpUI]
  );

  // Physics loop when running
  useEffect(() => {
    if (!isRunning) return;
    let rafId = 0;
    let uiCounter = 0;
    let accum = 0;

    const tick = () => {
      const stepsToRun = playbackSpeed >= 2 ? 2 : 1;
      accum += playbackSpeed < 1 ? playbackSpeed : 1;

      if (accum >= 1) {
        accum -= 1;
        for (let s = 0; s < stepsToRun; s++) {
          stepSimulation(simRef.current, scripts, dragSpringRef.current);

          // Record Tape frame
          const snap = captureTapeFrame(simRef.current);
          tapeFramesRef.current.push(snap);
          if (tapeFramesRef.current.length > 1500) {
            tapeFramesRef.current.shift();
          }

          // Sample meters
          setMeters((prev) =>
            prev.map((m) => {
              const sample = sampleBodyMetric(simRef.current, m);
              const nextData = [
                ...m.data,
                { t: simRef.current.time, v1: sample.v1, v2: sample.v2, v3: sample.v3 },
              ];
              if (nextData.length > 180) nextData.shift();
              return { ...m, data: nextData };
            })
          );

          // Check auto-stop time
          const stopAt = simRef.current.world.autoStopTime;
          if (stopAt !== null && simRef.current.time >= stopAt) {
            setIsRunning(false);
            setCurrentTapeIdx(tapeFramesRef.current.length - 1);
            bumpUI();
            return;
          }
        }
      }

      uiCounter += 1;
      if (uiCounter % 3 === 0) {
        setCurrentTapeIdx(tapeFramesRef.current.length - 1);
        bumpUI();
      }

      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [bumpUI, isRunning, playbackSpeed, scripts]);

  // Run / Stop toggle
  const handleRunToggle = useCallback(() => {
    setIsRunning((prev) => {
      if (!prev) {
        if (simRef.current.frame === 0) {
          initialResetRef.current = cloneSimulationState(simRef.current);
          tapeFramesRef.current = [captureTapeFrame(simRef.current)];
        }
        return true;
      }
      setCurrentTapeIdx(tapeFramesRef.current.length - 1);
      bumpUI();
      return false;
    });
  }, [bumpUI]);

  // Reset to initial state
  const handleReset = useCallback(() => {
    setIsRunning(false);
    simRef.current = cloneSimulationState(initialResetRef.current);
    tapeFramesRef.current = [captureTapeFrame(simRef.current)];
    setCurrentTapeIdx(0);
    setMeters((prev) => prev.map((m) => ({ ...m, data: [] })));
    bumpUI();
  }, [bumpUI]);

  // Step Forward 1 frame
  const handleStepForward = useCallback(() => {
    if (isRunning) return;
    if (simRef.current.frame === 0) {
      initialResetRef.current = cloneSimulationState(simRef.current);
    }
    if (currentTapeIdx < tapeFramesRef.current.length - 1) {
      const nextIdx = currentTapeIdx + 1;
      restoreTapeFrame(simRef.current, tapeFramesRef.current[nextIdx]);
      setCurrentTapeIdx(nextIdx);
      bumpUI();
      return;
    }
    stepSimulation(simRef.current, scripts, null);
    tapeFramesRef.current.push(captureTapeFrame(simRef.current));
    setCurrentTapeIdx(tapeFramesRef.current.length - 1);
    setMeters((prev) =>
      prev.map((m) => {
        const s = sampleBodyMetric(simRef.current, m);
        return {
          ...m,
          data: [...m.data.slice(-179), { t: simRef.current.time, v1: s.v1, v2: s.v2, v3: s.v3 }],
        };
      })
    );
    bumpUI();
  }, [bumpUI, currentTapeIdx, isRunning, scripts]);

  // Step Back 1 frame
  const handleStepBack = useCallback(() => {
    if (isRunning || currentTapeIdx <= 0) return;
    const prevIdx = currentTapeIdx - 1;
    restoreTapeFrame(simRef.current, tapeFramesRef.current[prevIdx]);
    setCurrentTapeIdx(prevIdx);
    bumpUI();
  }, [bumpUI, currentTapeIdx, isRunning]);

  const handleScrubFrame = useCallback(
    (idx: number) => {
      if (isRunning) return;
      const frame = tapeFramesRef.current[idx];
      if (!frame) return;
      restoreTapeFrame(simRef.current, frame);
      setCurrentTapeIdx(idx);
      bumpUI();
    },
    [bumpUI, isRunning]
  );

  // Load Preset
  const handleLoadPreset = useCallback(
    (presetId: string) => {
      setIsRunning(false);
      const bundle = loadPreset(presetId);
      simRef.current = cloneSimulationState(bundle.state);
      initialResetRef.current = cloneSimulationState(bundle.state);
      tapeFramesRef.current = [captureTapeFrame(simRef.current)];
      undoStackRef.current = [];
      redoStackRef.current = [];
      setCurrentTapeIdx(0);
      setCurrentPresetId(presetId);
      setMeters(bundle.meters);
      setControls(bundle.controls);
      setScripts([]);
      setSelection({ bodyIds: [], constraintId: null, annotationId: null });
      cameraRef.current = { panX: 0, panY: 0, ppm: 55 };
      bumpUI();
    },
    [bumpUI]
  );

  // Undo / Redo
  const handleUndo = useCallback(() => {
    const prev = undoStackRef.current.pop();
    if (!prev) return;
    redoStackRef.current.push(cloneSimulationState(simRef.current));
    simRef.current = prev;
    if (simRef.current.frame === 0) {
      initialResetRef.current = cloneSimulationState(simRef.current);
    }
    bumpUI();
  }, [bumpUI]);

  const handleRedo = useCallback(() => {
    const next = redoStackRef.current.pop();
    if (!next) return;
    undoStackRef.current.push(cloneSimulationState(simRef.current));
    simRef.current = next;
    if (simRef.current.frame === 0) {
      initialResetRef.current = cloneSimulationState(simRef.current);
    }
    bumpUI();
  }, [bumpUI]);

  // Selection Deletion & Clipboard
  const handleDeleteSelection = useCallback(() => {
    pushUndo();
    if (selection.bodyIds.length > 0) {
      const delSet = new Set(selection.bodyIds);
      simRef.current.bodies = simRef.current.bodies.filter((b) => !delSet.has(b.id));
      simRef.current.constraints = simRef.current.constraints.filter(
        (c) =>
          !(c.bodyAId && delSet.has(c.bodyAId)) &&
          !(c.bodyBId && delSet.has(c.bodyBId)) &&
          !(c.pulleyBodyId && delSet.has(c.pulleyBodyId))
      );
    }
    if (selection.constraintId) {
      simRef.current.constraints = simRef.current.constraints.filter(
        (c) => c.id !== selection.constraintId
      );
    }
    if (selection.annotationId) {
      simRef.current.annotations = simRef.current.annotations.filter(
        (a) => a.id !== selection.annotationId
      );
    }
    setSelection({ bodyIds: [], constraintId: null, annotationId: null });
    commitMutation(false);
  }, [commitMutation, pushUndo, selection]);

  const handleCopy = useCallback(() => {
    if (selection.bodyIds.length === 0) return;
    const selSet = new Set(selection.bodyIds);
    clipboardRef.current = simRef.current.bodies
      .filter((b) => selSet.has(b.id))
      .map((b) => JSON.parse(JSON.stringify(b)) as RigidBody);
  }, [selection.bodyIds]);

  const handleCut = useCallback(() => {
    handleCopy();
    handleDeleteSelection();
  }, [handleCopy, handleDeleteSelection]);

  const handlePaste = useCallback(() => {
    if (clipboardRef.current.length === 0) return;
    pushUndo();
    const newIds: string[] = [];
    for (const src of clipboardRef.current) {
      const copy = JSON.parse(JSON.stringify(src)) as RigidBody;
      copy.id = nextId('body');
      copy.name = `${src.name} Copy`;
      copy.x += 0.5;
      copy.y -= 0.5;
      copy.tracePoints = [];
      simRef.current.bodies.push(copy);
      newIds.push(copy.id);
    }
    setSelection({ bodyIds: newIds, constraintId: null, annotationId: null });
    commitMutation(false);
  }, [commitMutation, pushUndo]);

  const handleDuplicate = useCallback(() => {
    handleCopy();
    handlePaste();
  }, [handleCopy, handlePaste]);

  const handleSelectAll = useCallback(() => {
    setSelection({
      bodyIds: simRef.current.bodies.map((b) => b.id),
      constraintId: null,
      annotationId: null,
    });
  }, []);

  // File Save / Open / Export HTML
  const handleSaveJson = useCallback(() => {
    const data = JSON.stringify(
      {
        state: simRef.current,
        meters,
        controls,
        scripts,
      },
      null,
      2
    );
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `interactive-physics-${currentPresetId}.ipjson`;
    a.click();
    URL.revokeObjectURL(url);
  }, [controls, currentPresetId, meters, scripts]);

  const handleExportHtml = useCallback(() => {
    const html = generateStandaloneHtml(simRef.current, `Interactive Physics - ${currentPresetId}`);
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `interactive-physics-${currentPresetId}.html`;
    a.click();
    URL.revokeObjectURL(url);
  }, [currentPresetId]);

  const handleOpenFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        if (parsed && parsed.state && Array.isArray(parsed.state.bodies)) {
          setIsRunning(false);
          simRef.current = parsed.state;
          initialResetRef.current = cloneSimulationState(parsed.state);
          tapeFramesRef.current = [captureTapeFrame(parsed.state)];
          setCurrentTapeIdx(0);
          setMeters(parsed.meters ?? []);
          setControls(parsed.controls ?? []);
          setScripts(parsed.scripts ?? []);
          setSelection({ bodyIds: [], constraintId: null, annotationId: null });
          bumpUI();
        }
      } catch {
        // Ignore invalid JSON silently
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Update World / Body / Constraint / Annotation
  const handleUpdateWorld = useCallback(
    (patch: Partial<WorldSettings>) => {
      simRef.current.world = { ...simRef.current.world, ...patch };
      commitMutation(false);
    },
    [commitMutation]
  );

  const handleUpdateBody = useCallback(
    (id: string, mutate: (b: RigidBody) => void) => {
      const b = simRef.current.bodies.find((item) => item.id === id);
      if (b) {
        mutate(b);
        commitMutation(true);
      }
    },
    [commitMutation]
  );

  const handleUpdateConstraint = useCallback(
    (id: string, mutate: (c: PhysicsConstraint) => void) => {
      const c = simRef.current.constraints.find((item) => item.id === id);
      if (c) {
        mutate(c);
        commitMutation(true);
      }
    },
    [commitMutation]
  );

  const handleUpdateAnnotation = useCallback(
    (id: string, mutate: (a: TextAnnotation) => void) => {
      const a = simRef.current.annotations.find((item) => item.id === id);
      if (a) {
        mutate(a);
        commitMutation(true);
      }
    },
    [commitMutation]
  );

  // Meters & Controls
  const handleAddMeter = useCallback(
    (metric: MeterMetric, displayType: MeterDisplayType) => {
      const targetBody =
        selection.bodyIds.length > 0
          ? simRef.current.bodies.find((b) => b.id === selection.bodyIds[0])
          : simRef.current.bodies[0];
      const titleBase = metric.charAt(0).toUpperCase() + metric.slice(1);
      const offset = meters.length * 24;
      setMeters((prev) => [
        ...prev,
        {
          id: nextId('meter'),
          title: targetBody && metric !== 'time' ? `${targetBody.name} ${titleBase}` : titleBase,
          bodyId: targetBody ? targetBody.id : null,
          metric,
          displayType,
          x: 20 + offset,
          y: 20 + offset,
          width: displayType === 'digital' ? 230 : 265,
          height: displayType === 'digital' ? 115 : 155,
          data: [],
        },
      ]);
    },
    [meters.length, selection.bodyIds]
  );

  const handleControlValueChange = useCallback(
    (ctrl: ControlWidget, value: number) => {
      if (ctrl.targetType === 'world') {
        handleUpdateWorld({ [ctrl.property]: value } as Partial<WorldSettings>);
      } else if (ctrl.targetType === 'body' && ctrl.targetId) {
        handleUpdateBody(ctrl.targetId, (b) => {
          if (ctrl.property === 'mass') {
            b.mass = Math.max(0.05, value);
            recalcBodyMassProperties(b);
          } else if (ctrl.property === 'restitution') b.restitution = value;
          else if (ctrl.property === 'kineticFriction') b.kineticFriction = value;
          else if (ctrl.property === 'charge') b.charge = value;
        });
      } else if (ctrl.targetType === 'constraint' && ctrl.targetId) {
        handleUpdateConstraint(ctrl.targetId, (c) => {
          if (ctrl.property === 'stiffness') c.stiffness = value;
          else if (ctrl.property === 'damping') c.damping = value;
          else if (ctrl.property === 'motorTargetOmega') c.motorTargetOmega = value;
          else if (ctrl.property === 'forceX') c.forceX = value;
          else if (ctrl.property === 'forceY') c.forceY = value;
        });
      }
    },
    [handleUpdateBody, handleUpdateConstraint, handleUpdateWorld]
  );

  // Mesh Touching Gears
  const handleMeshGears = useCallback(() => {
    const gears =
      selection.bodyIds.length >= 2
        ? simRef.current.bodies.filter(
            (b) => selection.bodyIds.includes(b.id) && b.shape === 'gear'
          )
        : simRef.current.bodies.filter((b) => b.shape === 'gear');

    let added = 0;
    for (let i = 0; i < gears.length; i++) {
      for (let j = i + 1; j < gears.length; j++) {
        const g1 = gears[i];
        const g2 = gears[j];
        const dist = vLen(vSub({ x: g1.x, y: g1.y }, { x: g2.x, y: g2.y }));
        const sumR = g1.radius + g2.radius;
        if (dist <= sumR * 1.25) {
          const exists = simRef.current.constraints.some(
            (c) =>
              c.kind === 'gearMesh' &&
              ((c.bodyAId === g1.id && c.bodyBId === g2.id) ||
                (c.bodyAId === g2.id && c.bodyBId === g1.id))
          );
          if (!exists) {
            simRef.current.constraints.push({
              id: nextId('mesh'),
              name: `Mesh ${g1.name}-${g2.name}`,
              kind: 'gearMesh',
              bodyAId: g1.id,
              bodyBId: g2.id,
              localA: { x: 0, y: 0 },
              localB: { x: 0, y: 0 },
              enabled: true,
              color: '#475569',
            });
            added++;
          }
        }
      }
    }
    if (added > 0) commitMutation(true);
  }, [commitMutation, selection.bodyIds]);

  // Global keyboard shortcuts
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;

      if (e.code === 'Space') {
        e.preventDefault();
        handleRunToggle();
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        handleUndo();
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        handleRedo();
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'c') {
        e.preventDefault();
        handleCopy();
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'x') {
        e.preventDefault();
        handleCut();
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'v') {
        e.preventDefault();
        handlePaste();
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'd') {
        e.preventDefault();
        handleDuplicate();
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'a') {
        e.preventDefault();
        handleSelectAll();
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        handleSaveJson();
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'r') {
        e.preventDefault();
        handleReset();
        return;
      }
      if (e.key === 'Delete' || e.key === 'Backspace') {
        handleDeleteSelection();
        return;
      }

      // Tool single-key shortcuts
      const map: Record<string, ToolId> = {
        v: 'select',
        r: 'rotate',
        z: 'zoom',
        h: 'pan',
        b: 'rect',
        q: 'square',
        c: 'circle',
        p: 'polygon',
        a: 'anchor',
        s: 'spring',
        m: 'motor',
        g: 'gear',
        f: 'force',
        t: 'text',
      };
      const tool = map[e.key.toLowerCase()];
      if (tool && !e.ctrlKey && !e.metaKey && !e.altKey) {
        setActiveTool(tool);
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    handleCopy,
    handleCut,
    handleDeleteSelection,
    handleDuplicate,
    handlePaste,
    handleRedo,
    handleReset,
    handleRunToggle,
    handleSaveJson,
    handleSelectAll,
    handleUndo,
  ]);

  const world = simRef.current.world;
  const hasSelection =
    selection.bodyIds.length > 0 ||
    selection.constraintId !== null ||
    selection.annotationId !== null;

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden bg-[#ece9d8]">
      <input
        ref={fileInputRef}
        type="file"
        accept=".json,.ipjson"
        onChange={handleOpenFileChange}
        className="hidden"
      />

      {/* Top Menu Bar */}
      <MenuBar
        world={world}
        hasSelection={hasSelection}
        canUndo={undoStackRef.current.length > 0}
        canRedo={redoStackRef.current.length > 0}
        showPalette={showPalette}
        showProperties={showProperties}
        showTape={showTape}
        onNew={() => handleLoadPreset('blank')}
        onOpenFile={() => fileInputRef.current?.click()}
        onSaveJson={handleSaveJson}
        onExportHtml={handleExportHtml}
        onLoadPreset={handleLoadPreset}
        onUndo={handleUndo}
        onRedo={handleRedo}
        onCut={handleCut}
        onCopy={handleCopy}
        onPaste={handlePaste}
        onDuplicate={handleDuplicate}
        onDelete={handleDeleteSelection}
        onSelectAll={handleSelectAll}
        onClearTracks={() => {
          for (const b of simRef.current.bodies) b.tracePoints = [];
          bumpUI();
        }}
        onUpdateWorld={handleUpdateWorld}
        onZoomIn={() => {
          cameraRef.current.ppm = Math.min(240, cameraRef.current.ppm * 1.2);
          bumpUI();
        }}
        onZoomOut={() => {
          cameraRef.current.ppm = Math.max(12, cameraRef.current.ppm * 0.83);
          bumpUI();
        }}
        onZoomReset={() => {
          cameraRef.current = { panX: 0, panY: 0, ppm: 55 };
          bumpUI();
        }}
        onFitToObjects={() => {
          const bs = simRef.current.bodies;
          if (bs.length === 0) return;
          let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
          for (const b of bs) {
            minX = Math.min(minX, b.x - 1);
            maxX = Math.max(maxX, b.x + 1);
            minY = Math.min(minY, b.y - 1);
            maxY = Math.max(maxY, b.y + 1);
          }
          cameraRef.current.panX = (minX + maxX) / 2;
          cameraRef.current.panY = (minY + maxY) / 2;
          const span = Math.max(maxX - minX, maxY - minY, 4);
          cameraRef.current.ppm = Math.max(18, Math.min(120, 480 / span));
          bumpUI();
        }}
        onTogglePalette={() => setShowPalette((v) => !v)}
        onToggleProperties={() => setShowProperties((v) => !v)}
        onToggleTape={() => setShowTape((v) => !v)}
        onAddMeter={handleAddMeter}
        onClearMeters={() => setMeters([])}
        onTileMeters={() =>
          setMeters((prev) =>
            prev.map((m, i) => ({
              ...m,
              x: 16 + (i % 3) * 275,
              y: 16 + Math.floor(i / 3) * 165,
            }))
          )
        }
        onOpenDialog={(d) => setActiveDialog(d)}
        onToggleAnchor={() => {
          if (selection.bodyIds.length === 0) return;
          pushUndo();
          for (const id of selection.bodyIds) {
            const b = simRef.current.bodies.find((item) => item.id === id);
            if (b) {
              b.isStatic = !b.isStatic;
              b.vx = 0;
              b.vy = 0;
              b.omega = 0;
              recalcBodyMassProperties(b);
            }
          }
          commitMutation(false);
        }}
        onToggleCollide={() => {
          if (selection.bodyIds.length === 0) return;
          pushUndo();
          for (const id of selection.bodyIds) {
            const b = simRef.current.bodies.find((item) => item.id === id);
            if (b) b.collidable = !b.collidable;
          }
          commitMutation(false);
        }}
        onBringToFront={() => {
          if (selection.bodyIds.length === 0) return;
          const set = new Set(selection.bodyIds);
          const rest = simRef.current.bodies.filter((b) => !set.has(b.id));
          const sel = simRef.current.bodies.filter((b) => set.has(b.id));
          simRef.current.bodies = [...rest, ...sel];
          bumpUI();
        }}
        onSendToBack={() => {
          if (selection.bodyIds.length === 0) return;
          const set = new Set(selection.bodyIds);
          const rest = simRef.current.bodies.filter((b) => !set.has(b.id));
          const sel = simRef.current.bodies.filter((b) => set.has(b.id));
          simRef.current.bodies = [...sel, ...rest];
          bumpUI();
        }}
        onMeshSelectedGears={handleMeshGears}
      />

      {/* Top Toolbar */}
      <TopToolbar
        isRunning={isRunning}
        canStepBack={currentTapeIdx > 0}
        canUndo={undoStackRef.current.length > 0}
        canRedo={redoStackRef.current.length > 0}
        hasSelection={hasSelection}
        world={world}
        showProperties={showProperties}
        currentPresetId={currentPresetId}
        onRunToggle={handleRunToggle}
        onReset={handleReset}
        onStepBack={handleStepBack}
        onStepForward={handleStepForward}
        onNew={() => handleLoadPreset('blank')}
        onOpen={() => fileInputRef.current?.click()}
        onSave={handleSaveJson}
        onOpenHtmlCode={handleOpenHtmlCode}
        onLoadPreset={handleLoadPreset}
        onCut={handleCut}
        onCopy={handleCopy}
        onUndo={handleUndo}
        onRedo={handleRedo}
        onZoomIn={() => {
          cameraRef.current.ppm = Math.min(240, cameraRef.current.ppm * 1.2);
          bumpUI();
        }}
        onZoomOut={() => {
          cameraRef.current.ppm = Math.max(12, cameraRef.current.ppm * 0.83);
          bumpUI();
        }}
        onZoomReset={() => {
          cameraRef.current = { panX: 0, panY: 0, ppm: 55 };
          bumpUI();
        }}
        onUpdateWorld={handleUpdateWorld}
        onToggleProperties={() => setShowProperties((v) => !v)}
      />

      {/* Main Middle Workspace: Left Tool Palette + Center Canvas + Right Properties */}
      <div className="flex-1 flex min-h-0 relative">
        <LeftPalette
          activeTool={activeTool}
          onSelectTool={setActiveTool}
          visible={showPalette}
        />

        {/* Center Canvas + Floating Meters/Controls */}
        <main className="flex-1 relative min-w-0 h-full flex">
          <SimulationCanvas
            simRef={simRef}
            cameraRef={cameraRef}
            dragSpringRef={dragSpringRef}
            isRunning={isRunning}
            activeTool={activeTool}
            selection={selection}
            renderVersion={renderVersion}
            onSelect={setSelection}
            onCommitMutation={commitMutation}
            onChangeTool={setActiveTool}
            onCursorMove={setCursorWorld}
            onRequestTextPrompt={(pos) => {
              setPendingTextPos(pos);
              setPendingTextValue('Label');
            }}
          />

          <FloatingMeters
            simRef={simRef}
            meters={meters}
            controls={controls}
            precision={world.precision}
            renderVersion={renderVersion}
            onUpdateMeter={(id, patch) =>
              setMeters((prev) => prev.map((m) => (m.id === id ? { ...m, ...patch } : m)))
            }
            onRemoveMeter={(id) => setMeters((prev) => prev.filter((m) => m.id !== id))}
            onUpdateControlPosition={(id, x, y) =>
              setControls((prev) => prev.map((c) => (c.id === id ? { ...c, x, y } : c)))
            }
            onControlValueChange={handleControlValueChange}
            onRemoveControl={(id) => setControls((prev) => prev.filter((c) => c.id !== id))}
          />
        </main>

        <PropertiesPanel
          visible={showProperties}
          bodies={simRef.current.bodies}
          constraints={simRef.current.constraints}
          annotations={simRef.current.annotations}
          world={world}
          selection={selection}
          onUpdateBody={handleUpdateBody}
          onUpdateConstraint={handleUpdateConstraint}
          onUpdateAnnotation={handleUpdateAnnotation}
          onUpdateWorld={handleUpdateWorld}
          onDeleteSelection={handleDeleteSelection}
          onDuplicateSelection={handleDuplicate}
          onMeshGears={handleMeshGears}
        />
      </div>

      {/* Bottom Tape Player & Coordinate Status Bar */}
      <TapePlayerBar
        visible={showTape}
        isRunning={isRunning}
        time={simRef.current.time}
        frame={simRef.current.frame}
        totalFrames={tapeFramesRef.current.length}
        currentFrameIdx={currentTapeIdx}
        playbackSpeed={playbackSpeed}
        cursorWorld={cursorWorld}
        precision={world.precision}
        onScrubFrame={handleScrubFrame}
        onStepBack={handleStepBack}
        onStepForward={handleStepForward}
        onChangeSpeed={setPlaybackSpeed}
      />

      {/* Modal Dialogs */}
      <Dialogs
        activeDialog={activeDialog}
        world={world}
        bodies={simRef.current.bodies}
        constraints={simRef.current.constraints}
        scripts={scripts}
        onClose={() => setActiveDialog(null)}
        onUpdateWorld={handleUpdateWorld}
        onAddControl={(ctrl) => setControls((prev) => [...prev, ctrl])}
        onUpdateScripts={setScripts}
      />

      {/* In-app Text Annotation Input Modal */}
      {pendingTextPos && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (pendingTextValue.trim()) {
                const ann: TextAnnotation = {
                  id: nextId('txt'),
                  x: pendingTextPos.x,
                  y: pendingTextPos.y,
                  text: pendingTextValue.trim(),
                  fontSize: 15,
                  color: '#1e293b',
                };
                simRef.current.annotations.push(ann);
                setSelection({ bodyIds: [], constraintId: null, annotationId: ann.id });
                commitMutation(true);
              }
              setPendingTextPos(null);
            }}
            className="bg-[#f8fafc] border border-[#64748b] shadow-lg rounded-[3px] p-4 w-[320px] space-y-3 text-[12px]"
          >
            <div className="font-semibold text-[#1e293b]">Insert Workspace Text Label</div>
            <input
              autoFocus
              type="text"
              value={pendingTextValue}
              onChange={(e) => setPendingTextValue(e.target.value)}
              className="w-full px-2 py-1.5 bg-white border border-[#94a3b8] rounded"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setPendingTextPos(null)}
                className="px-3 py-1 bg-white border border-[#94a3b8] rounded"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-3 py-1 bg-[#2563eb] text-white rounded font-medium"
              >
                Insert
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Standalone HTML Code Viewer / Copy / Download Modal */}
      {htmlCodeModal.open && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-[#f8fafc] border border-[#64748b] shadow-2xl rounded-[3px] w-full max-w-[780px] h-[80vh] flex flex-col text-[12px]">
            <div className="h-[30px] bg-[#1e3a8a] text-white px-3 flex items-center justify-between shrink-0">
              <span className="font-semibold">Standalone HTML File (interactive-physics.html)</span>
              <button
                type="button"
                onClick={() => setHtmlCodeModal((prev) => ({ ...prev, open: false }))}
                className="px-1.5 py-0.5 hover:bg-white/20 rounded"
              >
                ✕
              </button>
            </div>
            <div className="px-3 py-2 bg-[#e2e8f0] border-b border-[#cbd5e1] flex flex-wrap items-center justify-between gap-2 shrink-0">
              <span className="text-[#334155]">
                Complete single-file HTML+CSS+JS version (also saved in root as <code className="font-mono-num font-semibold">interactive-physics.html</code>).
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard?.writeText(htmlCodeModal.code);
                    setHtmlCodeModal((prev) => ({ ...prev, copied: true }));
                  }}
                  className="px-3 py-1 bg-[#2563eb] text-white rounded font-medium hover:bg-[#1d4ed8]"
                >
                  {htmlCodeModal.copied ? 'Copied!' : 'Copy All Code'}
                </button>
                <a
                  href="/interactive-physics.html"
                  download="index.html"
                  className="px-3 py-1 bg-[#16a34a] text-white rounded font-medium hover:bg-[#15803d]"
                >
                  Download index.html
                </a>
              </div>
            </div>
            <textarea
              readOnly
              value={htmlCodeModal.code}
              className="flex-1 w-full p-3 font-mono-num text-[11px] bg-white text-[#0f172a] resize-none focus:outline-none"
            />
          </div>
        </div>
      )}
    </div>
  );
}
