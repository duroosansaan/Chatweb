import React from 'react';
import { ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight } from 'lucide-react';
import { Vec2 } from '../physics/types';

interface TapePlayerBarProps {
  visible: boolean;
  isRunning: boolean;
  time: number;
  frame: number;
  totalFrames: number;
  currentFrameIdx: number;
  playbackSpeed: number;
  cursorWorld: Vec2;
  precision: number;
  onScrubFrame: (idx: number) => void;
  onStepBack: () => void;
  onStepForward: () => void;
  onChangeSpeed: (speed: number) => void;
}

export const TapePlayerBar: React.FC<TapePlayerBarProps> = ({
  visible,
  isRunning,
  time,
  frame,
  totalFrames,
  currentFrameIdx,
  playbackSpeed,
  cursorWorld,
  precision,
  onScrubFrame,
  onStepBack,
  onStepForward,
  onChangeSpeed,
}) => {
  if (!visible) return null;

  const maxIdx = Math.max(0, totalFrames - 1);

  return (
    <footer
      aria-label="Tape Player and Coordinate Bar"
      className="h-[32px] bg-[#ece9d8] border-t border-[#9ca3af] px-2.5 flex items-center justify-between gap-3 text-[12px] text-[#1f2937] select-none z-20"
    >
      {/* Left: Tape Player Controls */}
      <div className="flex items-center gap-1.5">
        <span className="font-semibold text-[#475569] text-[11px] mr-1">Tape:</span>
        <button
          type="button"
          disabled={isRunning || maxIdx === 0}
          onClick={() => onScrubFrame(0)}
          title="Jump to Start Frame"
          className="p-0.5 rounded hover:bg-[#dbeafe] disabled:opacity-40"
        >
          <ChevronsLeft className="w-4 h-4" />
        </button>
        <button
          type="button"
          disabled={isRunning || currentFrameIdx <= 0}
          onClick={onStepBack}
          title="Step Back 1 Frame"
          className="p-0.5 rounded hover:bg-[#dbeafe] disabled:opacity-40"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        <input
          type="range"
          min={0}
          max={maxIdx}
          value={Math.min(currentFrameIdx, maxIdx)}
          disabled={isRunning || maxIdx === 0}
          onChange={(e) => onScrubFrame(Number(e.target.value))}
          aria-label="Simulation Tape Scrubber"
          className="w-[150px] sm:w-[220px] accent-[#2563eb] cursor-pointer disabled:opacity-50"
        />

        <button
          type="button"
          disabled={isRunning}
          onClick={onStepForward}
          title="Step Forward 1 Frame"
          className="p-0.5 rounded hover:bg-[#dbeafe] disabled:opacity-40"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
        <button
          type="button"
          disabled={isRunning || maxIdx === 0}
          onClick={() => onScrubFrame(maxIdx)}
          title="Jump to Latest Recorded Frame"
          className="p-0.5 rounded hover:bg-[#dbeafe] disabled:opacity-40"
        >
          <ChevronsRight className="w-4 h-4" />
        </button>
      </div>

      {/* Center: Time, Frame, Speed */}
      <div className="flex items-center gap-3 font-mono-num text-[11px]">
        <div>
          <span className="text-[#64748b] mr-1">Time:</span>
          <span className="font-semibold text-[#0f172a]">{time.toFixed(precision)} s</span>
        </div>
        <div className="hidden sm:block">
          <span className="text-[#64748b] mr-1">Frame:</span>
          <span className="font-semibold text-[#0f172a]">{frame}</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="text-[#64748b]">Speed:</span>
          <select
            value={playbackSpeed}
            onChange={(e) => onChangeSpeed(Number(e.target.value))}
            aria-label="Playback Speed"
            className="bg-white border border-[#94a3b8] rounded-[2px] px-1 py-0 text-[11px] font-mono-num"
          >
            <option value={0.25}>0.25x</option>
            <option value={0.5}>0.5x</option>
            <option value={1}>1x</option>
            <option value={2}>2x</option>
          </select>
        </div>
      </div>

      {/* Right: Live World Coordinates */}
      <div className="font-mono-num text-[11px] text-[#334155] whitespace-nowrap">
        X: <span className="font-semibold">{cursorWorld.x.toFixed(precision)}</span> m · Y:{' '}
        <span className="font-semibold">{cursorWorld.y.toFixed(precision)}</span> m
      </div>
    </footer>
  );
};
