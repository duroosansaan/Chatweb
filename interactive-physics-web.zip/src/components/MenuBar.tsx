import React, { useEffect, useRef, useState } from 'react';
import { PRESET_LIST } from '../physics/presets';
import { MeterDisplayType, MeterMetric, WorldSettings } from '../physics/types';

export interface MenuBarProps {
  world: WorldSettings;
  hasSelection: boolean;
  canUndo: boolean;
  canRedo: boolean;
  showPalette: boolean;
  showProperties: boolean;
  showTape: boolean;
  onNew: () => void;
  onOpenFile: () => void;
  onSaveJson: () => void;
  onExportHtml: () => void;
  onLoadPreset: (id: string) => void;
  onUndo: () => void;
  onRedo: () => void;
  onCut: () => void;
  onCopy: () => void;
  onPaste: () => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onSelectAll: () => void;
  onClearTracks: () => void;
  onUpdateWorld: (patch: Partial<WorldSettings>) => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onZoomReset: () => void;
  onFitToObjects: () => void;
  onTogglePalette: () => void;
  onToggleProperties: () => void;
  onToggleTape: () => void;
  onAddMeter: (metric: MeterMetric, displayType: MeterDisplayType) => void;
  onClearMeters: () => void;
  onTileMeters: () => void;
  onOpenDialog: (
    dialog:
      | 'gravity'
      | 'air'
      | 'accuracy'
      | 'units'
      | 'vectors'
      | 'newControl'
      | 'script'
      | 'help'
      | 'about'
  ) => void;
  onToggleAnchor: () => void;
  onToggleCollide: () => void;
  onBringToFront: () => void;
  onSendToBack: () => void;
  onMeshSelectedGears: () => void;
}

type MenuKey =
  | 'file'
  | 'edit'
  | 'world'
  | 'view'
  | 'define'
  | 'measure'
  | 'object'
  | 'script'
  | 'window'
  | 'help';

export const MenuBar: React.FC<MenuBarProps> = (props) => {
  const [openMenu, setOpenMenu] = useState<MenuKey | null>(null);
  const [subMenu, setSubMenu] = useState<string | null>(null);
  const barRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleDown = (e: PointerEvent) => {
      if (barRef.current && !barRef.current.contains(e.target as Node)) {
        setOpenMenu(null);
        setSubMenu(null);
      }
    };
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpenMenu(null);
        setSubMenu(null);
      }
    };
    window.addEventListener('pointerdown', handleDown);
    window.addEventListener('keydown', handleKey);
    return () => {
      window.removeEventListener('pointerdown', handleDown);
      window.removeEventListener('keydown', handleKey);
    };
  }, []);

  const close = () => {
    setOpenMenu(null);
    setSubMenu(null);
  };

  const run = (fn: () => void) => {
    close();
    fn();
  };

  const menus: Array<{ key: MenuKey; label: string }> = [
    { key: 'file', label: 'File' },
    { key: 'edit', label: 'Edit' },
    { key: 'world', label: 'World' },
    { key: 'view', label: 'View' },
    { key: 'define', label: 'Define' },
    { key: 'measure', label: 'Measure' },
    { key: 'object', label: 'Object' },
    { key: 'script', label: 'Script' },
    { key: 'window', label: 'Window' },
    { key: 'help', label: 'Help' },
  ];

  return (
    <nav
      ref={barRef}
      aria-label="Main Menu"
      className="h-[28px] bg-[#ece9d8] border-b border-[#aca899] px-1.5 flex items-center gap-0.5 text-[12px] text-[#111827] relative z-30 select-none"
    >
      <div className="font-bold text-[#1e3a8a] pr-2 mr-1 border-r border-[#cbd5e1] whitespace-nowrap shrink-0 flex items-center gap-1.5">
        <span className="inline-block w-2.5 h-2.5 bg-[#2563eb] rounded-[2px]" />
        <span>Interactive Physics</span>
      </div>

      {menus.map((m) => {
        const isOpen = openMenu === m.key;
        return (
          <div key={m.key} className="relative">
            <button
              type="button"
              onClick={() => {
                setOpenMenu(isOpen ? null : m.key);
                setSubMenu(null);
              }}
              onMouseEnter={() => {
                if (openMenu && openMenu !== m.key) {
                  setOpenMenu(m.key);
                  setSubMenu(null);
                }
              }}
              className={`px-2 py-0.5 rounded-[2px] whitespace-nowrap shrink-0 transition-colors ${
                isOpen
                  ? 'bg-[#2563eb] text-white'
                  : 'hover:bg-[#dbeafe] text-[#111827]'
              }`}
            >
              {m.label}
            </button>

            {isOpen && (
              <div className="absolute left-0 top-full mt-0.5 min-w-[230px] bg-[#f8fafc] border border-[#94a3b8] shadow-md py-1 z-50 text-[12px] text-[#111827]">
                {m.key === 'file' && (
                  <>
                    <MenuItem label="New Workspace" shortcut="Ctrl+N" onClick={() => run(props.onNew)} />
                    <MenuItem label="Open Simulation (.ipjson)..." shortcut="Ctrl+O" onClick={() => run(props.onOpenFile)} />
                    <MenuItem label="Save Simulation (.ipjson)" shortcut="Ctrl+S" onClick={() => run(props.onSaveJson)} />
                    <MenuItem label="Export Scene Snapshot (.html)" onClick={() => run(props.onExportHtml)} />
                    <a
                      href="/interactive-physics.html"
                      download="interactive-physics.html"
                      onClick={() => close()}
                      className="w-full px-3 py-1.5 flex items-center justify-between gap-4 text-left hover:bg-[#2563eb] hover:text-white text-[#111827]"
                    >
                      <span className="flex items-center gap-2">
                        <span className="w-3" />
                        <span>Download Complete App (.html)</span>
                      </span>
                    </a>
                    <MenuDivider />
                    <div
                      className="relative"
                      onMouseEnter={() => setSubMenu('presets')}
                      onMouseLeave={() => setSubMenu(null)}
                    >
                      <button
                        type="button"
                        onClick={() => setSubMenu(subMenu === 'presets' ? null : 'presets')}
                        className="w-full px-3 py-1.5 flex items-center justify-between hover:bg-[#2563eb] hover:text-white text-left"
                      >
                        <span>Sample Experiments</span>
                        <span className="text-[10px]">▶</span>
                      </button>
                      {subMenu === 'presets' && (
                        <div className="absolute left-full top-0 min-w-[260px] bg-[#f8fafc] border border-[#94a3b8] shadow-md py-1 z-50">
                          {PRESET_LIST.map((p) => (
                            <button
                              key={p.id}
                              type="button"
                              onClick={() => run(() => props.onLoadPreset(p.id))}
                              className="w-full px-3 py-1.5 text-left hover:bg-[#2563eb] hover:text-white flex flex-col"
                            >
                              <span className="font-medium">{p.name}</span>
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </>
                )}

                {m.key === 'edit' && (
                  <>
                    <MenuItem label="Undo" shortcut="Ctrl+Z" disabled={!props.canUndo} onClick={() => run(props.onUndo)} />
                    <MenuItem label="Redo" shortcut="Ctrl+Y" disabled={!props.canRedo} onClick={() => run(props.onRedo)} />
                    <MenuDivider />
                    <MenuItem label="Cut" shortcut="Ctrl+X" disabled={!props.hasSelection} onClick={() => run(props.onCut)} />
                    <MenuItem label="Copy" shortcut="Ctrl+C" disabled={!props.hasSelection} onClick={() => run(props.onCopy)} />
                    <MenuItem label="Paste" shortcut="Ctrl+V" onClick={() => run(props.onPaste)} />
                    <MenuItem label="Duplicate" shortcut="Ctrl+D" disabled={!props.hasSelection} onClick={() => run(props.onDuplicate)} />
                    <MenuItem label="Delete" shortcut="Del" disabled={!props.hasSelection} onClick={() => run(props.onDelete)} />
                    <MenuDivider />
                    <MenuItem label="Select All" shortcut="Ctrl+A" onClick={() => run(props.onSelectAll)} />
                    <MenuItem label="Erase All Tracks" onClick={() => run(props.onClearTracks)} />
                  </>
                )}

                {m.key === 'world' && (
                  <>
                    <MenuItem
                      label={`Gravity... (${props.world.gravityMode === 'none' ? 'Off' : props.world.gravityMode === 'planetary' ? 'Planetary' : `${props.world.gy} m/s²`})`}
                      onClick={() => run(() => props.onOpenDialog('gravity'))}
                    />
                    <MenuItem
                      label={`Air Resistance... (${props.world.airResistance})`}
                      onClick={() => run(() => props.onOpenDialog('air'))}
                    />
                    <MenuItem
                      label="Electrostatics (Coulomb)"
                      checked={props.world.electrostaticsEnabled}
                      onClick={() =>
                        run(() =>
                          props.onUpdateWorld({
                            electrostaticsEnabled: !props.world.electrostaticsEnabled,
                          })
                        )
                      }
                    />
                    <MenuDivider />
                    <MenuItem
                      label="Accuracy / Solver Settings..."
                      onClick={() => run(() => props.onOpenDialog('accuracy'))}
                    />
                  </>
                )}

                {m.key === 'view' && (
                  <>
                    <MenuItem
                      label="Show Grid Lines"
                      checked={props.world.showGrid}
                      onClick={() => run(() => props.onUpdateWorld({ showGrid: !props.world.showGrid }))}
                    />
                    <MenuItem
                      label="Snap to Grid"
                      checked={props.world.snapToGrid}
                      onClick={() => run(() => props.onUpdateWorld({ snapToGrid: !props.world.snapToGrid }))}
                    />
                    <MenuItem
                      label="Show Rulers"
                      checked={props.world.showRulers}
                      onClick={() => run(() => props.onUpdateWorld({ showRulers: !props.world.showRulers }))}
                    />
                    <MenuItem
                      label="Show X-Y Origin Axes"
                      checked={props.world.showAxes}
                      onClick={() => run(() => props.onUpdateWorld({ showAxes: !props.world.showAxes }))}
                    />
                    <MenuItem
                      label="Show Center of Mass"
                      checked={props.world.showCOM}
                      onClick={() => run(() => props.onUpdateWorld({ showCOM: !props.world.showCOM }))}
                    />
                    <MenuItem
                      label="Show Path Tracking"
                      checked={props.world.showTrackPoints}
                      onClick={() => run(() => props.onUpdateWorld({ showTrackPoints: !props.world.showTrackPoints }))}
                    />
                    <MenuDivider />
                    <MenuItem label="Numbers and Units..." onClick={() => run(() => props.onOpenDialog('units'))} />
                    <MenuDivider />
                    <MenuItem label="Zoom In" shortcut="+" onClick={() => run(props.onZoomIn)} />
                    <MenuItem label="Zoom Out" shortcut="-" onClick={() => run(props.onZoomOut)} />
                    <MenuItem label="View 100% (Reset Camera)" onClick={() => run(props.onZoomReset)} />
                    <MenuItem label="Fit All Objects" onClick={() => run(props.onFitToObjects)} />
                    <MenuDivider />
                    <MenuItem label="Tool Palette" checked={props.showPalette} onClick={() => run(props.onTogglePalette)} />
                    <MenuItem label="Properties Window" checked={props.showProperties} onClick={() => run(props.onToggleProperties)} />
                    <MenuItem label="Tape Player Bar" checked={props.showTape} onClick={() => run(props.onToggleTape)} />
                  </>
                )}

                {m.key === 'define' && (
                  <>
                    <MenuItem label="Vectors (Velocity, Force, Accel)..." onClick={() => run(() => props.onOpenDialog('vectors'))} />
                    <MenuItem label="New Slider Control..." onClick={() => run(() => props.onOpenDialog('newControl'))} />
                    <MenuDivider />
                    <MenuItem
                      label="Velocity Vectors"
                      checked={props.world.showVectors.velocity}
                      onClick={() =>
                        run(() =>
                          props.onUpdateWorld({
                            showVectors: {
                              ...props.world.showVectors,
                              velocity: !props.world.showVectors.velocity,
                            },
                          })
                        )
                      }
                    />
                    <MenuItem
                      label="Acceleration Vectors"
                      checked={props.world.showVectors.acceleration}
                      onClick={() =>
                        run(() =>
                          props.onUpdateWorld({
                            showVectors: {
                              ...props.world.showVectors,
                              acceleration: !props.world.showVectors.acceleration,
                            },
                          })
                        )
                      }
                    />
                    <MenuItem
                      label="Total Force Vectors"
                      checked={props.world.showVectors.force}
                      onClick={() =>
                        run(() =>
                          props.onUpdateWorld({
                            showVectors: {
                              ...props.world.showVectors,
                              force: !props.world.showVectors.force,
                            },
                          })
                        )
                      }
                    />
                    <MenuItem
                      label="Gravity Vectors"
                      checked={props.world.showVectors.gravity}
                      onClick={() =>
                        run(() =>
                          props.onUpdateWorld({
                            showVectors: {
                              ...props.world.showVectors,
                              gravity: !props.world.showVectors.gravity,
                            },
                          })
                        )
                      }
                    />
                  </>
                )}

                {m.key === 'measure' && (
                  <>
                    {(
                      [
                        { metric: 'position', label: 'Position (X, Y, θ)' },
                        { metric: 'velocity', label: 'Velocity (Vx, Vy, |V|)' },
                        { metric: 'acceleration', label: 'Acceleration (Ax, Ay, |A|)' },
                        { metric: 'force', label: 'Total Force (Fx, Fy, |F|)' },
                        { metric: 'momentum', label: 'Momentum (Px, Py, |P|)' },
                        { metric: 'energy', label: 'Kinetic & Potential Energy' },
                        { metric: 'time', label: 'Time & Frame' },
                      ] as Array<{ metric: MeterMetric; label: string }>
                    ).map((item) => (
                      <div
                        key={item.metric}
                        className="relative"
                        onMouseEnter={() => setSubMenu(`m_${item.metric}`)}
                        onMouseLeave={() => setSubMenu(null)}
                      >
                        <button
                          type="button"
                          onClick={() => run(() => props.onAddMeter(item.metric, 'graph'))}
                          className="w-full px-3 py-1.5 flex items-center justify-between hover:bg-[#2563eb] hover:text-white text-left"
                        >
                          <span>{item.label}</span>
                          <span className="text-[10px]">▶</span>
                        </button>
                        {subMenu === `m_${item.metric}` && (
                          <div className="absolute left-full top-0 min-w-[140px] bg-[#f8fafc] border border-[#94a3b8] shadow-md py-1 z-50">
                            <MenuItem label="Graph" onClick={() => run(() => props.onAddMeter(item.metric, 'graph'))} />
                            <MenuItem label="Digital Readout" onClick={() => run(() => props.onAddMeter(item.metric, 'digital'))} />
                            <MenuItem label="Bar Gauge" onClick={() => run(() => props.onAddMeter(item.metric, 'bar'))} />
                          </div>
                        )}
                      </div>
                    ))}
                  </>
                )}

                {m.key === 'object' && (
                  <>
                    <MenuItem label="Properties Window" onClick={() => run(() => { if (!props.showProperties) props.onToggleProperties(); })} />
                    <MenuDivider />
                    <MenuItem label="Anchor / Unanchor Body" disabled={!props.hasSelection} onClick={() => run(props.onToggleAnchor)} />
                    <MenuItem label="Toggle Collidable" disabled={!props.hasSelection} onClick={() => run(props.onToggleCollide)} />
                    <MenuItem label="Mesh Touching Gears" onClick={() => run(props.onMeshSelectedGears)} />
                    <MenuDivider />
                    <MenuItem label="Move to Front" disabled={!props.hasSelection} onClick={() => run(props.onBringToFront)} />
                    <MenuItem label="Send to Back" disabled={!props.hasSelection} onClick={() => run(props.onSendToBack)} />
                  </>
                )}

                {m.key === 'script' && (
                  <>
                    <MenuItem label="Formula & Script Editor..." onClick={() => run(() => props.onOpenDialog('script'))} />
                  </>
                )}

                {m.key === 'window' && (
                  <>
                    <MenuItem label="Arrange / Tile Meters" onClick={() => run(props.onTileMeters)} />
                    <MenuItem label="Close All Meters" onClick={() => run(props.onClearMeters)} />
                  </>
                )}

                {m.key === 'help' && (
                  <>
                    <MenuItem label="Tool Guide & Shortcuts..." onClick={() => run(() => props.onOpenDialog('help'))} />
                    <MenuItem label="About Interactive Physics Web..." onClick={() => run(() => props.onOpenDialog('about'))} />
                  </>
                )}
              </div>
            )}
          </div>
        );
      })}
    </nav>
  );
};

const MenuItem: React.FC<{
  label: string;
  shortcut?: string;
  checked?: boolean;
  disabled?: boolean;
  onClick: () => void;
}> = ({ label, shortcut, checked, disabled, onClick }) => (
  <button
    type="button"
    disabled={disabled}
    onClick={onClick}
    className={`w-full px-3 py-1.5 flex items-center justify-between gap-4 text-left ${
      disabled
        ? 'text-[#9ca3af] cursor-default'
        : 'hover:bg-[#2563eb] hover:text-white text-[#111827]'
    }`}
  >
    <span className="flex items-center gap-2">
      <span className="w-3 text-center font-bold">{checked ? '✓' : ''}</span>
      <span>{label}</span>
    </span>
    {shortcut && <span className="text-[11px] opacity-75 font-mono-num">{shortcut}</span>}
  </button>
);

const MenuDivider: React.FC = () => <div className="my-1 border-t border-[#d1d5db]" />;
