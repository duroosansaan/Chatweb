import React from 'react';
import {
  ArrowUpRight,
  Code2,
  Copy,
  FilePlus,
  FolderOpen,
  Grid,
  Magnet,
  PanelRight,
  Play,
  Redo2,
  RotateCcw,
  Ruler,
  Save,
  Scissors,
  SkipBack,
  SkipForward,
  SlidersHorizontal,
  Square,
  Undo2,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import { PRESET_LIST } from '../physics/presets';
import { WorldSettings } from '../physics/types';

interface TopToolbarProps {
  isRunning: boolean;
  canStepBack: boolean;
  canUndo: boolean;
  canRedo: boolean;
  hasSelection: boolean;
  world: WorldSettings;
  showProperties: boolean;
  currentPresetId: string;
  onRunToggle: () => void;
  onReset: () => void;
  onStepBack: () => void;
  onStepForward: () => void;
  onNew: () => void;
  onOpen: () => void;
  onSave: () => void;
  onOpenHtmlCode: () => void;
  onLoadPreset: (id: string) => void;
  onCut: () => void;
  onCopy: () => void;
  onUndo: () => void;
  onRedo: () => void;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onZoomReset: () => void;
  onUpdateWorld: (patch: Partial<WorldSettings>) => void;
  onToggleProperties: () => void;
}

export const TopToolbar: React.FC<TopToolbarProps> = ({
  isRunning,
  canStepBack,
  canUndo,
  canRedo,
  hasSelection,
  world,
  showProperties,
  currentPresetId,
  onRunToggle,
  onReset,
  onStepBack,
  onStepForward,
  onNew,
  onOpen,
  onSave,
  onOpenHtmlCode,
  onLoadPreset,
  onCut,
  onCopy,
  onUndo,
  onRedo,
  onZoomIn,
  onZoomOut,
  onZoomReset,
  onUpdateWorld,
  onToggleProperties,
}) => {
  const anyVectorOn =
    world.showVectors.velocity ||
    world.showVectors.acceleration ||
    world.showVectors.force ||
    world.showVectors.gravity;

  return (
    <div
      role="toolbar"
      aria-label="Simulation Toolbar"
      className="h-[36px] bg-[#f1f5f9] border-b border-[#9ca3af] px-2 flex items-center gap-1 overflow-x-auto select-none z-20"
    >
      {/* File actions */}
      <ToolBtn title="New Workspace (Ctrl+N)" onClick={onNew}>
        <FilePlus className="w-4 h-4" />
      </ToolBtn>
      <ToolBtn title="Open Simulation (Ctrl+O)" onClick={onOpen}>
        <FolderOpen className="w-4 h-4" />
      </ToolBtn>
      <ToolBtn title="Save Simulation (Ctrl+S)" onClick={onSave}>
        <Save className="w-4 h-4" />
      </ToolBtn>

      <Sep />

      {/* Edit actions */}
      <ToolBtn title="Cut (Ctrl+X)" disabled={!hasSelection} onClick={onCut}>
        <Scissors className="w-4 h-4" />
      </ToolBtn>
      <ToolBtn title="Copy (Ctrl+C)" disabled={!hasSelection} onClick={onCopy}>
        <Copy className="w-4 h-4" />
      </ToolBtn>
      <ToolBtn title="Undo (Ctrl+Z)" disabled={!canUndo} onClick={onUndo}>
        <Undo2 className="w-4 h-4" />
      </ToolBtn>
      <ToolBtn title="Redo (Ctrl+Y)" disabled={!canRedo} onClick={onRedo}>
        <Redo2 className="w-4 h-4" />
      </ToolBtn>

      <Sep />

      {/* Camera & Workspace */}
      <ToolBtn title="Zoom In" onClick={onZoomIn}>
        <ZoomIn className="w-4 h-4" />
      </ToolBtn>
      <ToolBtn title="Zoom Out" onClick={onZoomOut}>
        <ZoomOut className="w-4 h-4" />
      </ToolBtn>
      <ToolBtn title="Reset View 100%" onClick={onZoomReset}>
        <span className="text-[11px] font-semibold font-mono-num">1:1</span>
      </ToolBtn>
      <ToolBtn
        title="Toggle Grid"
        active={world.showGrid}
        onClick={() => onUpdateWorld({ showGrid: !world.showGrid })}
      >
        <Grid className="w-4 h-4" />
      </ToolBtn>
      <ToolBtn
        title="Toggle Rulers"
        active={world.showRulers}
        onClick={() => onUpdateWorld({ showRulers: !world.showRulers })}
      >
        <Ruler className="w-4 h-4" />
      </ToolBtn>
      <ToolBtn
        title="Snap to Grid"
        active={world.snapToGrid}
        onClick={() => onUpdateWorld({ snapToGrid: !world.snapToGrid })}
      >
        <Magnet className="w-4 h-4" />
      </ToolBtn>

      <Sep />

      {/* Iconic Interactive Physics Run / Stop / Reset / Step Cluster */}
      <div className="flex items-center gap-1 bg-[#e2e8f0] px-1.5 py-0.5 rounded-[3px] border border-[#cbd5e1]">
        <button
          type="button"
          onClick={onRunToggle}
          title={isRunning ? 'Stop Simulation (Space)' : 'Run Simulation (Space)'}
          className={`h-[26px] px-3 rounded-[2px] flex items-center gap-1.5 text-[12px] font-semibold border transition-colors whitespace-nowrap shrink-0 ${
            isRunning
              ? 'bg-[#dc2626] border-[#991b1b] text-white hover:bg-[#b91c1c]'
              : 'bg-[#16a34a] border-[#15803d] text-white hover:bg-[#15803d]'
          }`}
        >
          {isRunning ? (
            <>
              <Square className="w-3.5 h-3.5 fill-current" />
              <span>Stop</span>
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Run</span>
            </>
          )}
        </button>

        <button
          type="button"
          onClick={onReset}
          title="Reset Simulation to Initial State (Ctrl+R)"
          className="h-[26px] px-2.5 rounded-[2px] flex items-center gap-1 text-[12px] font-medium bg-white border border-[#94a3b8] text-[#1e293b] hover:bg-[#f8fafc] whitespace-nowrap shrink-0"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>

        <ToolBtn title="Step Back 1 Frame" disabled={isRunning || !canStepBack} onClick={onStepBack}>
          <SkipBack className="w-3.5 h-3.5" />
        </ToolBtn>
        <ToolBtn title="Step Forward 1 Frame" disabled={isRunning} onClick={onStepForward}>
          <SkipForward className="w-3.5 h-3.5" />
        </ToolBtn>
      </div>

      <Sep />

      {/* Vectors & Quick Lab Preset */}
      <ToolBtn
        title="Toggle Velocity & Force Vectors"
        active={anyVectorOn}
        onClick={() =>
          onUpdateWorld({
            showVectors: {
              ...world.showVectors,
              velocity: !anyVectorOn,
              force: !anyVectorOn,
            },
          })
        }
      >
        <ArrowUpRight className="w-4 h-4" />
      </ToolBtn>

      <div className="flex items-center gap-1.5 ml-1">
        <SlidersHorizontal className="w-3.5 h-3.5 text-[#475569]" />
        <label htmlFor="preset-select" className="text-[11px] font-medium text-[#475569] whitespace-nowrap">
          Experiments:
        </label>
        <select
          id="preset-select"
          value={currentPresetId}
          onChange={(e) => onLoadPreset(e.target.value)}
          className="h-[24px] px-1.5 text-[12px] bg-white border border-[#94a3b8] rounded-[2px] text-[#111827] focus:outline-none focus:border-[#2563eb]"
        >
          {PRESET_LIST.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name}
            </option>
          ))}
        </select>
      </div>

      <div className="ml-auto flex items-center gap-1">
        <button
          type="button"
          title="View, Copy, or Download Standalone index.html"
          onClick={onOpenHtmlCode}
          className="h-[26px] px-2 rounded-[2px] flex items-center gap-1 text-[11px] font-semibold bg-white border border-[#94a3b8] text-[#1e3a8a] hover:bg-[#dbeafe] whitespace-nowrap shrink-0"
        >
          <Code2 className="w-3.5 h-3.5" />
          <span>HTML Code</span>
        </button>
        <ToolBtn
          title="Toggle Properties Window"
          active={showProperties}
          onClick={onToggleProperties}
        >
          <PanelRight className="w-4 h-4" />
        </ToolBtn>
      </div>
    </div>
  );
};

const ToolBtn: React.FC<{
  title: string;
  active?: boolean;
  disabled?: boolean;
  onClick: () => void;
  children: React.ReactNode;
}> = ({ title, active, disabled, onClick, children }) => (
  <button
    type="button"
    title={title}
    disabled={disabled}
    onClick={onClick}
    className={`h-[26px] min-w-[26px] px-1.5 rounded-[2px] flex items-center justify-center border transition-colors shrink-0 ${
      disabled
        ? 'opacity-40 cursor-default border-transparent text-[#64748b]'
        : active
        ? 'bg-[#dbeafe] border-[#2563eb] text-[#1d4ed8]'
        : 'bg-transparent border-transparent text-[#1f2937] hover:bg-[#e2e8f0] hover:border-[#cbd5e1]'
    }`}
  >
    {children}
  </button>
);

const Sep: React.FC = () => <div className="h-5 w-[1px] bg-[#cbd5e1] mx-1 shrink-0" />;
