import React from 'react';
import { ToolId } from '../physics/types';
import { ToolIcon } from './ToolIcons';

export interface ToolDescriptor {
  id: ToolId;
  label: string;
  shortcut?: string;
  hint: string;
}

export const TOOL_GROUPS: ToolDescriptor[][] = [
  [
    { id: 'select', label: 'Select', shortcut: 'V', hint: 'Select, move, resize, or grab objects' },
    { id: 'rotate', label: 'Rotate', shortcut: 'R', hint: 'Rotate selected body around center' },
    { id: 'zoom', label: 'Zoom', shortcut: 'Z', hint: 'Click to zoom in, Alt+Click to zoom out' },
    { id: 'pan', label: 'Pan', shortcut: 'H', hint: 'Drag to pan the workspace' },
  ],
  [
    { id: 'rect', label: 'Rectangle', shortcut: 'B', hint: 'Drag to draw a rectangular body' },
    { id: 'square', label: 'Square', shortcut: 'Q', hint: 'Drag to draw an equal-sided square' },
    { id: 'circle', label: 'Circle', shortcut: 'C', hint: 'Drag from center to draw a circle' },
    { id: 'polygon', label: 'Polygon', shortcut: 'P', hint: 'Click vertices, double-click to close polygon' },
    { id: 'point', label: 'Point Element', hint: 'Place a marker or attachment point' },
    { id: 'anchor', label: 'Anchor', shortcut: 'A', hint: 'Click a body to pin/fix it in place' },
  ],
  [
    { id: 'pin', label: 'Pin Joint', hint: 'Click on bodies to create a rotating hinge' },
    { id: 'weld', label: 'Rigid Joint', hint: 'Weld overlapping bodies rigidly together' },
    { id: 'hslot', label: 'Horizontal Slot', hint: 'Constrain body to slide horizontally' },
    { id: 'vslot', label: 'Vertical Slot', hint: 'Constrain body to slide vertically' },
    { id: 'slot', label: 'Angled Slot', hint: 'Drag to draw a keyed/angled slot rail' },
    { id: 'rod', label: 'Rod', hint: 'Drag between two points to attach a rigid rod' },
  ],
  [
    { id: 'spring', label: 'Spring', shortcut: 'S', hint: 'Drag between two points to attach a Hooke spring' },
    { id: 'damper', label: 'Damper', hint: 'Drag between two points to attach a dashpot damper' },
    { id: 'rope', label: 'Rope', hint: 'Drag between two points (tension-only rope)' },
    { id: 'actuator', label: 'Actuator', hint: 'Drag to attach a powered linear actuator' },
  ],
  [
    { id: 'motor', label: 'Motor', shortcut: 'M', hint: 'Click a body to attach a rotary motor' },
    { id: 'gear', label: 'Gear', shortcut: 'G', hint: 'Drag to create a toothed gear wheel' },
    { id: 'pulley', label: 'Pulley', hint: 'Drag to create a pulley wheel' },
    { id: 'force', label: 'Force', shortcut: 'F', hint: 'Drag from a body point to apply a force vector' },
    { id: 'torque', label: 'Torque', hint: 'Click a body to apply a rotational torque' },
    { id: 'thruster', label: 'Thruster', hint: 'Click a body to attach a local rocket thruster' },
  ],
  [
    { id: 'text', label: 'Text', shortcut: 'T', hint: 'Click on workspace to place a text label' },
  ],
];

interface LeftPaletteProps {
  activeTool: ToolId;
  onSelectTool: (tool: ToolId) => void;
  visible: boolean;
}

export const LeftPalette: React.FC<LeftPaletteProps> = ({
  activeTool,
  onSelectTool,
  visible,
}) => {
  if (!visible) return null;

  const activeDesc =
    TOOL_GROUPS.flat().find((t) => t.id === activeTool) ?? TOOL_GROUPS[0][0];

  return (
    <aside
      aria-label="Tool Palette"
      className="w-[78px] shrink-0 bg-[#ece9d8] border-r border-[#9ca3af] flex flex-col justify-between select-none z-10"
    >
      <div className="p-1.5 overflow-y-auto flex-1">
        {TOOL_GROUPS.map((group, gIdx) => (
          <div key={gIdx} className={gIdx > 0 ? 'mt-1.5 pt-1.5 border-t border-[#cbd5e1]' : ''}>
            <div className="grid grid-cols-2 gap-1">
              {group.map((tool) => {
                const isActive = activeTool === tool.id;
                return (
                  <button
                    key={tool.id}
                    type="button"
                    onClick={() => onSelectTool(tool.id)}
                    title={`${tool.label}${tool.shortcut ? ` (${tool.shortcut})` : ''} — ${tool.hint}`}
                    aria-label={tool.label}
                    aria-pressed={isActive}
                    className={`h-[30px] w-full flex items-center justify-center rounded-[2px] border transition-colors ${
                      isActive
                        ? 'bg-[#dbeafe] border-[#2563eb] text-[#1d4ed8] shadow-inner'
                        : 'bg-[#f8fafc] border-[#cbd5e1] text-[#1f2937] hover:bg-[#e2e8f0] hover:border-[#94a3b8]'
                    }`}
                  >
                    <ToolIcon tool={tool.id} className="w-[18px] h-[18px]" />
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Active tool mini label at bottom of palette */}
      <div className="px-1.5 py-1.5 border-t border-[#9ca3af] bg-[#e2e8f0] text-center">
        <div className="text-[11px] font-semibold text-[#1e293b] truncate leading-tight">
          {activeDesc.label}
        </div>
        {activeDesc.shortcut && (
          <div className="text-[10px] text-[#475569] font-mono-num">
            Key: {activeDesc.shortcut}
          </div>
        )}
      </div>
    </aside>
  );
};
