import React, { useRef } from 'react';
import { BarChart2, Hash, LineChart, X } from 'lucide-react';
import { sampleBodyMetric } from '../physics/engine';
import {
  ControlWidget,
  MeterDisplayType,
  MeterWidget,
  SimulationState,
} from '../physics/types';

interface FloatingMetersProps {
  simRef: React.MutableRefObject<SimulationState>;
  meters: MeterWidget[];
  controls: ControlWidget[];
  precision: number;
  renderVersion: number;
  onUpdateMeter: (id: string, patch: Partial<MeterWidget>) => void;
  onRemoveMeter: (id: string) => void;
  onUpdateControlPosition: (id: string, x: number, y: number) => void;
  onControlValueChange: (control: ControlWidget, value: number) => void;
  onRemoveControl: (id: string) => void;
}

export const FloatingMeters: React.FC<FloatingMetersProps> = ({
  simRef,
  meters,
  controls,
  precision,
  onUpdateMeter,
  onRemoveMeter,
  onUpdateControlPosition,
  onControlValueChange,
  onRemoveControl,
}) => {
  const dragStateRef = useRef<{
    kind: 'meter' | 'control';
    id: string;
    startClientX: number;
    startClientY: number;
    origX: number;
    origY: number;
  } | null>(null);

  const startDrag = (
    e: React.PointerEvent,
    kind: 'meter' | 'control',
    id: string,
    origX: number,
    origY: number
  ) => {
    e.stopPropagation();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    dragStateRef.current = {
      kind,
      id,
      startClientX: e.clientX,
      startClientY: e.clientY,
      origX,
      origY,
    };
  };

  const moveDrag = (e: React.PointerEvent) => {
    const d = dragStateRef.current;
    if (!d) return;
    const nx = Math.max(4, d.origX + (e.clientX - d.startClientX));
    const ny = Math.max(4, d.origY + (e.clientY - d.startClientY));
    if (d.kind === 'meter') onUpdateMeter(d.id, { x: nx, y: ny });
    else onUpdateControlPosition(d.id, nx, ny);
  };

  const endDrag = (e: React.PointerEvent) => {
    if (dragStateRef.current) {
      try {
        (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
      } catch {
        // ignore
      }
      dragStateRef.current = null;
    }
  };

  const getControlCurrentValue = (ctrl: ControlWidget): number => {
    const state = simRef.current;
    if (ctrl.targetType === 'world') {
      if (ctrl.property === 'gy') return state.world.gy;
      if (ctrl.property === 'gx') return state.world.gx;
      if (ctrl.property === 'airResistance') return state.world.airResistance;
    } else if (ctrl.targetType === 'body' && ctrl.targetId) {
      const b = state.bodies.find((item) => item.id === ctrl.targetId);
      if (b) {
        if (ctrl.property === 'mass') return b.mass;
        if (ctrl.property === 'restitution') return b.restitution;
        if (ctrl.property === 'kineticFriction') return b.kineticFriction;
        if (ctrl.property === 'charge') return b.charge;
      }
    } else if (ctrl.targetType === 'constraint' && ctrl.targetId) {
      const c = state.constraints.find((item) => item.id === ctrl.targetId);
      if (c) {
        if (ctrl.property === 'stiffness') return c.stiffness ?? 50;
        if (ctrl.property === 'damping') return c.damping ?? 0.5;
        if (ctrl.property === 'motorTargetOmega') return c.motorTargetOmega ?? 0;
        if (ctrl.property === 'forceX') return c.forceX ?? 0;
        if (ctrl.property === 'forceY') return c.forceY ?? 0;
      }
    }
    return 0;
  };

  return (
    <div className="absolute inset-0 pointer-events-none z-20 overflow-hidden">
      {/* Floating Meters */}
      {meters.map((m) => {
        const sample = sampleBodyMetric(simRef.current, m);
        const switchType = (t: MeterDisplayType) => onUpdateMeter(m.id, { displayType: t });

        return (
          <div
            key={m.id}
            style={{ left: m.x, top: m.y, width: m.width }}
            className="absolute pointer-events-auto bg-[#f8fafc] border border-[#64748b] shadow-md rounded-[2px] flex flex-col text-[11px]"
          >
            {/* Title bar */}
            <div
              onPointerDown={(e) => startDrag(e, 'meter', m.id, m.x, m.y)}
              onPointerMove={moveDrag}
              onPointerUp={endDrag}
              onPointerCancel={endDrag}
              style={{ touchAction: 'none' }}
              className="h-[22px] bg-[#1e3a8a] text-white px-1.5 flex items-center justify-between cursor-move select-none"
            >
              <span className="font-medium truncate pr-2">{m.title}</span>
              <div className="flex items-center gap-0.5 shrink-0">
                <button
                  type="button"
                  title="Graph View"
                  onPointerDown={(e) => e.stopPropagation()}
                  onClick={() => switchType('graph')}
                  className={`p-0.5 rounded ${m.displayType === 'graph' ? 'bg-white/25' : 'hover:bg-white/15'}`}
                >
                  <LineChart className="w-3 h-3" />
                </button>
                <button
                  type="button"
                  title="Digital Readout"
                  onPointerDown={(e) => e.stopPropagation()}
                  onClick={() => switchType('digital')}
                  className={`p-0.5 rounded ${m.displayType === 'digital' ? 'bg-white/25' : 'hover:bg-white/15'}`}
                >
                  <Hash className="w-3 h-3" />
                </button>
                <button
                  type="button"
                  title="Bar Gauge"
                  onPointerDown={(e) => e.stopPropagation()}
                  onClick={() => switchType('bar')}
                  className={`p-0.5 rounded ${m.displayType === 'bar' ? 'bg-white/25' : 'hover:bg-white/15'}`}
                >
                  <BarChart2 className="w-3 h-3" />
                </button>
                <button
                  type="button"
                  title="Close Meter"
                  onPointerDown={(e) => e.stopPropagation()}
                  onClick={() => onRemoveMeter(m.id)}
                  className="p-0.5 rounded hover:bg-[#dc2626] ml-0.5"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            </div>

            {/* Meter Body */}
            <div className="p-2 bg-white">
              {m.displayType === 'digital' && (
                <div className="space-y-1 font-mono-num">
                  <div className="flex justify-between">
                    <span className="text-[#2563eb] font-semibold">{sample.labels[0]}:</span>
                    <span>{sample.v1.toFixed(precision)} {sample.unit}</span>
                  </div>
                  {sample.labels[1] && (
                    <div className="flex justify-between">
                      <span className="text-[#16a34a] font-semibold">{sample.labels[1]}:</span>
                      <span>{sample.v2.toFixed(precision)} {sample.unit}</span>
                    </div>
                  )}
                  {sample.labels[2] && (
                    <div className="flex justify-between">
                      <span className="text-[#dc2626] font-semibold">{sample.labels[2]}:</span>
                      <span>{sample.v3.toFixed(precision)} {sample.unit}</span>
                    </div>
                  )}
                </div>
              )}

              {m.displayType === 'bar' && (
                <div className="space-y-1.5 font-mono-num">
                  {[
                    { label: sample.labels[0], val: sample.v1, color: '#2563eb' },
                    { label: sample.labels[1], val: sample.v2, color: '#16a34a' },
                    { label: sample.labels[2], val: sample.v3, color: '#dc2626' },
                  ]
                    .filter((row) => row.label)
                    .map((row, i) => {
                      const pct = Math.min(100, Math.abs(row.val) * 5);
                      return (
                        <div key={i}>
                          <div className="flex justify-between text-[10px]">
                            <span>{row.label}</span>
                            <span>{row.val.toFixed(precision)}</span>
                          </div>
                          <div className="h-2 bg-[#e2e8f0] rounded-sm overflow-hidden">
                            <div
                              style={{ width: `${pct}%`, backgroundColor: row.color }}
                              className="h-full"
                            />
                          </div>
                        </div>
                      );
                    })}
                </div>
              )}

              {m.displayType === 'graph' && (
                <div>
                  <MeterGraph data={m.data} labels={sample.labels} height={Math.max(85, m.height - 52)} />
                  <div className="mt-1 flex items-center justify-between font-mono-num text-[10px] text-[#334155]">
                    <span className="text-[#2563eb]">{sample.labels[0]}: {sample.v1.toFixed(precision)}</span>
                    {sample.labels[1] && (
                      <span className="text-[#16a34a]">{sample.labels[1]}: {sample.v2.toFixed(precision)}</span>
                    )}
                    {sample.labels[2] && (
                      <span className="text-[#dc2626]">{sample.labels[2]}: {sample.v3.toFixed(precision)}</span>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        );
      })}

      {/* Floating Slider Controls */}
      {controls.map((ctrl) => {
        const val = getControlCurrentValue(ctrl);
        return (
          <div
            key={ctrl.id}
            style={{ left: ctrl.x, top: ctrl.y }}
            className="absolute pointer-events-auto w-[220px] bg-[#ece9d8] border border-[#64748b] shadow-md rounded-[2px] text-[11px]"
          >
            <div
              onPointerDown={(e) => startDrag(e, 'control', ctrl.id, ctrl.x, ctrl.y)}
              onPointerMove={moveDrag}
              onPointerUp={endDrag}
              onPointerCancel={endDrag}
              style={{ touchAction: 'none' }}
              className="h-[20px] bg-[#475569] text-white px-1.5 flex items-center justify-between cursor-move select-none"
            >
              <span className="font-medium truncate">{ctrl.label}</span>
              <button
                type="button"
                onPointerDown={(e) => e.stopPropagation()}
                onClick={() => onRemoveControl(ctrl.id)}
                className="p-0.5 rounded hover:bg-[#dc2626]"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
            <div className="p-2 bg-[#f8fafc] space-y-1">
              <div className="flex justify-between font-mono-num text-[11px]">
                <span className="text-[#64748b]">{ctrl.min}</span>
                <span className="font-semibold text-[#0f172a]">
                  {val.toFixed(2)} {ctrl.unit}
                </span>
                <span className="text-[#64748b]">{ctrl.max}</span>
              </div>
              <input
                type="range"
                min={ctrl.min}
                max={ctrl.max}
                step={ctrl.step}
                value={val}
                onChange={(e) => onControlValueChange(ctrl, parseFloat(e.target.value))}
                className="w-full accent-[#2563eb] cursor-pointer"
              />
            </div>
          </div>
        );
      })}
    </div>
  );
};

const MeterGraph: React.FC<{
  data: Array<{ t: number; v1: number; v2: number; v3: number }>;
  labels: [string, string, string];
  height: number;
}> = ({ data, labels, height }) => {
  const width = 235;
  let minV = -1;
  let maxV = 1;

  if (data.length > 0) {
    minV = Infinity;
    maxV = -Infinity;
    for (const pt of data) {
      if (pt.v1 < minV) minV = pt.v1;
      if (pt.v1 > maxV) maxV = pt.v1;
      if (labels[1]) {
        if (pt.v2 < minV) minV = pt.v2;
        if (pt.v2 > maxV) maxV = pt.v2;
      }
      if (labels[2]) {
        if (pt.v3 < minV) minV = pt.v3;
        if (pt.v3 > maxV) maxV = pt.v3;
      }
    }
    if (Math.abs(maxV - minV) < 1e-4) {
      minV -= 1;
      maxV += 1;
    } else {
      const pad = (maxV - minV) * 0.1;
      minV -= pad;
      maxV += pad;
    }
  }

  const buildPath = (pick: (d: { v1: number; v2: number; v3: number }) => number) => {
    if (data.length < 2) return '';
    return data
      .map((d, idx) => {
        const x = (idx / (data.length - 1)) * width;
        const y = height - ((pick(d) - minV) / (maxV - minV)) * height;
        return `${idx === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  };

  const zeroY = height - ((0 - minV) / (maxV - minV)) * height;

  return (
    <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} className="bg-[#f8fafc] border border-[#cbd5e1]">
      {zeroY >= 0 && zeroY <= height && (
        <line x1={0} y1={zeroY} x2={width} y2={zeroY} stroke="#cbd5e1" strokeWidth="1" strokeDasharray="3 3" />
      )}
      {data.length >= 2 && (
        <>
          <path d={buildPath((d) => d.v1)} fill="none" stroke="#2563eb" strokeWidth="1.5" />
          {labels[1] && <path d={buildPath((d) => d.v2)} fill="none" stroke="#16a34a" strokeWidth="1.5" />}
          {labels[2] && <path d={buildPath((d) => d.v3)} fill="none" stroke="#dc2626" strokeWidth="1.5" />}
        </>
      )}
      <text x="3" y="10" fontSize="9" fill="#64748b" fontFamily="monospace">
        {maxV.toFixed(1)}
      </text>
      <text x="3" y={height - 3} fontSize="9" fill="#64748b" fontFamily="monospace">
        {minV.toFixed(1)}
      </text>
    </svg>
  );
};
