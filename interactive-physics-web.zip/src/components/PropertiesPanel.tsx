import React from 'react';
import { Anchor, Copy, Trash2 } from 'lucide-react';
import { getRectVertices, recalcBodyMassProperties } from '../physics/math';
import {
  PhysicsConstraint,
  RigidBody,
  TextAnnotation,
  WorldSettings,
} from '../physics/types';
import { SelectionState } from './SimulationCanvas';

interface PropertiesPanelProps {
  visible: boolean;
  bodies: RigidBody[];
  constraints: PhysicsConstraint[];
  annotations: TextAnnotation[];
  world: WorldSettings;
  selection: SelectionState;
  onUpdateBody: (id: string, mutate: (b: RigidBody) => void) => void;
  onUpdateConstraint: (id: string, mutate: (c: PhysicsConstraint) => void) => void;
  onUpdateAnnotation: (id: string, mutate: (a: TextAnnotation) => void) => void;
  onUpdateWorld: (patch: Partial<WorldSettings>) => void;
  onDeleteSelection: () => void;
  onDuplicateSelection: () => void;
  onMeshGears: () => void;
}

export const PropertiesPanel: React.FC<PropertiesPanelProps> = ({
  visible,
  bodies,
  constraints,
  annotations,
  world,
  selection,
  onUpdateBody,
  onUpdateConstraint,
  onUpdateAnnotation,
  onUpdateWorld,
  onDeleteSelection,
  onDuplicateSelection,
  onMeshGears,
}) => {
  if (!visible) return null;

  const selectedBody =
    selection.bodyIds.length === 1
      ? bodies.find((b) => b.id === selection.bodyIds[0]) ?? null
      : null;

  const selectedConstraint = selection.constraintId
    ? constraints.find((c) => c.id === selection.constraintId) ?? null
    : null;

  const selectedAnnotation = selection.annotationId
    ? annotations.find((a) => a.id === selection.annotationId) ?? null
    : null;

  return (
    <aside
      aria-label="Properties Inspector"
      className="w-[264px] shrink-0 bg-[#f1f5f9] border-l border-[#9ca3af] flex flex-col h-full overflow-y-auto text-[12px] text-[#111827] z-10"
    >
      <div className="px-3 py-2 bg-[#e2e8f0] border-b border-[#cbd5e1] flex items-center justify-between">
        <span className="font-semibold text-[#1e293b]">
          {selectedBody
            ? 'Object Properties'
            : selectedConstraint
            ? 'Constraint Properties'
            : selectedAnnotation
            ? 'Text Properties'
            : selection.bodyIds.length > 1
            ? `${selection.bodyIds.length} Objects Selected`
            : 'Workspace Properties'}
        </span>
        {(selectedBody || selectedConstraint || selectedAnnotation || selection.bodyIds.length > 0) && (
          <div className="flex items-center gap-1">
            {selection.bodyIds.length > 0 && (
              <button
                type="button"
                title="Duplicate"
                onClick={onDuplicateSelection}
                className="p-1 rounded hover:bg-[#cbd5e1] text-[#334155]"
              >
                <Copy className="w-3.5 h-3.5" />
              </button>
            )}
            <button
              type="button"
              title="Delete Selected"
              onClick={onDeleteSelection}
              className="p-1 rounded hover:bg-[#fecaca] text-[#dc2626]"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {/* Multi-selection summary */}
      {selection.bodyIds.length > 1 && (
        <div className="p-3 space-y-3">
          <p className="text-[#475569]">
            {selection.bodyIds.length} bodies selected. You can drag them together, duplicate, or mesh two gears.
          </p>
          <button
            type="button"
            onClick={onMeshGears}
            className="w-full py-1.5 px-2.5 bg-[#2563eb] text-white rounded text-[12px] font-medium hover:bg-[#1d4ed8]"
          >
            Mesh Selected Gears
          </button>
        </div>
      )}

      {/* Single Body Inspector */}
      {selectedBody && (
        <div className="p-3 space-y-3">
          <div className="space-y-1.5">
            <label className="block text-[11px] font-semibold text-[#475569]">Name & State</label>
            <input
              type="text"
              value={selectedBody.name}
              onChange={(e) =>
                onUpdateBody(selectedBody.id, (b) => {
                  b.name = e.target.value;
                })
              }
              className="w-full px-2 py-1 bg-white border border-[#cbd5e1] rounded text-[12px]"
            />
            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() =>
                  onUpdateBody(selectedBody.id, (b) => {
                    b.isStatic = !b.isStatic;
                    b.vx = 0;
                    b.vy = 0;
                    b.omega = 0;
                    recalcBodyMassProperties(b);
                  })
                }
                className={`flex-1 py-1 px-2 rounded border text-[11px] font-medium flex items-center justify-center gap-1 ${
                  selectedBody.isStatic
                    ? 'bg-[#dbeafe] border-[#2563eb] text-[#1d4ed8]'
                    : 'bg-white border-[#cbd5e1] text-[#334155]'
                }`}
              >
                <Anchor className="w-3 h-3" />
                <span>{selectedBody.isStatic ? 'Anchored' : 'Dynamic'}</span>
              </button>
              <label className="flex items-center gap-1.5 text-[11px] cursor-pointer">
                <input
                  type="checkbox"
                  checked={selectedBody.collidable}
                  onChange={(e) =>
                    onUpdateBody(selectedBody.id, (b) => {
                      b.collidable = e.target.checked;
                    })
                  }
                />
                <span>Collide</span>
              </label>
            </div>
          </div>

          {/* Kinematics */}
          <Section title="Position & Velocity">
            <div className="grid grid-cols-2 gap-2">
              <NumField
                label="X (m)"
                value={selectedBody.x}
                step={0.1}
                onChange={(v) => onUpdateBody(selectedBody.id, (b) => { b.x = v; })}
              />
              <NumField
                label="Y (m)"
                value={selectedBody.y}
                step={0.1}
                onChange={(v) => onUpdateBody(selectedBody.id, (b) => { b.y = v; })}
              />
              <NumField
                label="Angle (°)"
                value={(selectedBody.angle * 180) / Math.PI}
                step={5}
                onChange={(v) =>
                  onUpdateBody(selectedBody.id, (b) => {
                    b.angle = (v * Math.PI) / 180;
                  })
                }
              />
              <NumField
                label="ω (rad/s)"
                value={selectedBody.omega}
                step={0.2}
                onChange={(v) => onUpdateBody(selectedBody.id, (b) => { b.omega = v; })}
              />
              <NumField
                label="Vx (m/s)"
                value={selectedBody.vx}
                step={0.5}
                onChange={(v) => onUpdateBody(selectedBody.id, (b) => { b.vx = v; })}
              />
              <NumField
                label="Vy (m/s)"
                value={selectedBody.vy}
                step={0.5}
                onChange={(v) => onUpdateBody(selectedBody.id, (b) => { b.vy = v; })}
              />
            </div>
          </Section>

          {/* Dimensions */}
          {(selectedBody.shape === 'rect' ||
            selectedBody.shape === 'circle' ||
            selectedBody.shape === 'gear' ||
            selectedBody.shape === 'pulley') && (
            <Section title="Geometry">
              <div className="grid grid-cols-2 gap-2">
                {selectedBody.shape === 'rect' ? (
                  <>
                    <NumField
                      label="Width (m)"
                      value={selectedBody.width}
                      min={0.1}
                      step={0.1}
                      onChange={(v) =>
                        onUpdateBody(selectedBody.id, (b) => {
                          b.width = Math.max(0.1, v);
                          b.vertices = getRectVertices(b.width, b.height);
                          recalcBodyMassProperties(b);
                        })
                      }
                    />
                    <NumField
                      label="Height (m)"
                      value={selectedBody.height}
                      min={0.1}
                      step={0.1}
                      onChange={(v) =>
                        onUpdateBody(selectedBody.id, (b) => {
                          b.height = Math.max(0.1, v);
                          b.vertices = getRectVertices(b.width, b.height);
                          recalcBodyMassProperties(b);
                        })
                      }
                    />
                  </>
                ) : (
                  <NumField
                    label="Radius (m)"
                    value={selectedBody.radius}
                    min={0.1}
                    step={0.05}
                    onChange={(v) =>
                      onUpdateBody(selectedBody.id, (b) => {
                        b.radius = Math.max(0.1, v);
                        recalcBodyMassProperties(b);
                      })
                    }
                  />
                )}
                {selectedBody.shape === 'gear' && (
                  <NumField
                    label="Teeth"
                    value={selectedBody.teeth}
                    min={6}
                    step={1}
                    onChange={(v) =>
                      onUpdateBody(selectedBody.id, (b) => {
                        b.teeth = Math.max(6, Math.round(v));
                      })
                    }
                  />
                )}
              </div>
            </Section>
          )}

          {/* Material */}
          <Section title="Material & Physics">
            <div className="grid grid-cols-2 gap-2">
              <NumField
                label="Mass (kg)"
                value={selectedBody.mass}
                min={0.05}
                step={0.5}
                onChange={(v) =>
                  onUpdateBody(selectedBody.id, (b) => {
                    b.mass = Math.max(0.05, v);
                    recalcBodyMassProperties(b);
                  })
                }
              />
              <NumField
                label="Elasticity (e)"
                value={selectedBody.restitution}
                min={0}
                max={1}
                step={0.05}
                onChange={(v) =>
                  onUpdateBody(selectedBody.id, (b) => {
                    b.restitution = Math.max(0, Math.min(1, v));
                  })
                }
              />
              <NumField
                label="Static μs"
                value={selectedBody.staticFriction}
                min={0}
                max={2}
                step={0.05}
                onChange={(v) =>
                  onUpdateBody(selectedBody.id, (b) => {
                    b.staticFriction = Math.max(0, v);
                  })
                }
              />
              <NumField
                label="Kinetic μk"
                value={selectedBody.kineticFriction}
                min={0}
                max={2}
                step={0.05}
                onChange={(v) =>
                  onUpdateBody(selectedBody.id, (b) => {
                    b.kineticFriction = Math.max(0, v);
                  })
                }
              />
              <NumField
                label="Charge (q)"
                value={selectedBody.charge}
                step={0.5}
                onChange={(v) => onUpdateBody(selectedBody.id, (b) => { b.charge = v; })}
              />
              <NumField
                label="Collide Group"
                value={selectedBody.collisionGroup}
                min={0}
                step={1}
                onChange={(v) =>
                  onUpdateBody(selectedBody.id, (b) => {
                    b.collisionGroup = Math.max(0, Math.round(v));
                  })
                }
              />
            </div>
          </Section>

          {/* Thruster if attached */}
          {selectedBody.thruster && (
            <Section title="Attached Thruster">
              <label className="flex items-center gap-2 text-[11px] mb-1.5">
                <input
                  type="checkbox"
                  checked={selectedBody.thruster.enabled}
                  onChange={(e) =>
                    onUpdateBody(selectedBody.id, (b) => {
                      if (b.thruster) b.thruster.enabled = e.target.checked;
                    })
                  }
                />
                <span>Thruster Active</span>
              </label>
              <div className="grid grid-cols-2 gap-2">
                <NumField
                  label="Thrust Fx (N)"
                  value={selectedBody.thruster.fx}
                  step={2}
                  onChange={(v) =>
                    onUpdateBody(selectedBody.id, (b) => {
                      if (b.thruster) b.thruster.fx = v;
                    })
                  }
                />
                <NumField
                  label="Thrust Fy (N)"
                  value={selectedBody.thruster.fy}
                  step={2}
                  onChange={(v) =>
                    onUpdateBody(selectedBody.id, (b) => {
                      if (b.thruster) b.thruster.fy = v;
                    })
                  }
                />
              </div>
            </Section>
          )}

          {/* Appearance */}
          <Section title="Appearance & Tracking">
            <div className="flex items-center gap-3 mb-2">
              <label className="flex items-center gap-1.5 text-[11px]">
                <span>Fill</span>
                <input
                  type="color"
                  value={selectedBody.fillColor}
                  onChange={(e) =>
                    onUpdateBody(selectedBody.id, (b) => {
                      b.fillColor = e.target.value;
                    })
                  }
                  className="w-6 h-5 border border-[#cbd5e1] cursor-pointer"
                />
              </label>
              <label className="flex items-center gap-1.5 text-[11px]">
                <span>Border</span>
                <input
                  type="color"
                  value={selectedBody.strokeColor}
                  onChange={(e) =>
                    onUpdateBody(selectedBody.id, (b) => {
                      b.strokeColor = e.target.value;
                    })
                  }
                  className="w-6 h-5 border border-[#cbd5e1] cursor-pointer"
                />
              </label>
            </div>
            <div className="space-y-1">
              <CheckField
                label="Track Path Trajectory"
                checked={selectedBody.trackCOM}
                onChange={(c) => onUpdateBody(selectedBody.id, (b) => { b.trackCOM = c; })}
              />
              <CheckField
                label="Show Center of Mass"
                checked={selectedBody.showCOM}
                onChange={(c) => onUpdateBody(selectedBody.id, (b) => { b.showCOM = c; })}
              />
              <CheckField
                label="Show Object Name"
                checked={selectedBody.showName}
                onChange={(c) => onUpdateBody(selectedBody.id, (b) => { b.showName = c; })}
              />
            </div>
          </Section>
        </div>
      )}

      {/* Constraint Inspector */}
      {selectedConstraint && (
        <div className="p-3 space-y-3">
          <div>
            <label className="block text-[11px] font-semibold text-[#475569] mb-1">Name</label>
            <input
              type="text"
              value={selectedConstraint.name}
              onChange={(e) =>
                onUpdateConstraint(selectedConstraint.id, (c) => {
                  c.name = e.target.value;
                })
              }
              className="w-full px-2 py-1 bg-white border border-[#cbd5e1] rounded text-[12px]"
            />
          </div>

          <CheckField
            label="Constraint Active"
            checked={selectedConstraint.enabled}
            onChange={(v) =>
              onUpdateConstraint(selectedConstraint.id, (c) => {
                c.enabled = v;
              })
            }
          />

          {selectedConstraint.kind === 'spring' && (
            <Section title="Spring Parameters">
              <div className="grid grid-cols-2 gap-2">
                <NumField
                  label="Stiffness k (N/m)"
                  value={selectedConstraint.stiffness ?? 50}
                  min={0}
                  step={5}
                  onChange={(v) =>
                    onUpdateConstraint(selectedConstraint.id, (c) => {
                      c.stiffness = Math.max(0, v);
                    })
                  }
                />
                <NumField
                  label="Rest Length (m)"
                  value={selectedConstraint.restLength ?? 1.5}
                  min={0.05}
                  step={0.1}
                  onChange={(v) =>
                    onUpdateConstraint(selectedConstraint.id, (c) => {
                      c.restLength = Math.max(0.05, v);
                    })
                  }
                />
                <NumField
                  label="Damping (N·s/m)"
                  value={selectedConstraint.damping ?? 0.4}
                  min={0}
                  step={0.2}
                  onChange={(v) =>
                    onUpdateConstraint(selectedConstraint.id, (c) => {
                      c.damping = Math.max(0, v);
                    })
                  }
                />
              </div>
            </Section>
          )}

          {selectedConstraint.kind === 'damper' && (
            <Section title="Damper Parameters">
              <NumField
                label="Damping c (N·s/m)"
                value={selectedConstraint.damping ?? 8}
                min={0}
                step={0.5}
                onChange={(v) =>
                  onUpdateConstraint(selectedConstraint.id, (c) => {
                    c.damping = Math.max(0, v);
                  })
                }
              />
            </Section>
          )}

          {selectedConstraint.kind === 'rope' && (
            <Section title="Rope Parameters">
              <NumField
                label="Max Length (m)"
                value={selectedConstraint.maxLength ?? selectedConstraint.restLength ?? 2}
                min={0.1}
                step={0.1}
                onChange={(v) =>
                  onUpdateConstraint(selectedConstraint.id, (c) => {
                    c.maxLength = Math.max(0.1, v);
                  })
                }
              />
            </Section>
          )}

          {selectedConstraint.kind === 'rod' && (
            <Section title="Rod Parameters">
              <NumField
                label="Rod Length (m)"
                value={selectedConstraint.restLength ?? 1.5}
                min={0.1}
                step={0.1}
                onChange={(v) =>
                  onUpdateConstraint(selectedConstraint.id, (c) => {
                    c.restLength = Math.max(0.1, v);
                  })
                }
              />
            </Section>
          )}

          {selectedConstraint.kind === 'actuator' && (
            <Section title="Linear Actuator">
              <div className="space-y-2">
                <select
                  value={selectedConstraint.actuatorMode ?? 'sine'}
                  onChange={(e) =>
                    onUpdateConstraint(selectedConstraint.id, (c) => {
                      c.actuatorMode = e.target.value as 'sine' | 'velocity';
                    })
                  }
                  className="w-full px-2 py-1 bg-white border border-[#cbd5e1] rounded text-[12px]"
                >
                  <option value="sine">Oscillating (Sine Wave)</option>
                  <option value="velocity">Constant Extension Speed</option>
                </select>
                <div className="grid grid-cols-2 gap-2">
                  <NumField
                    label="Base Length (m)"
                    value={selectedConstraint.restLength ?? 1.5}
                    min={0.2}
                    step={0.1}
                    onChange={(v) =>
                      onUpdateConstraint(selectedConstraint.id, (c) => {
                        c.restLength = Math.max(0.2, v);
                      })
                    }
                  />
                  {selectedConstraint.actuatorMode === 'velocity' ? (
                    <NumField
                      label="Speed (m/s)"
                      value={selectedConstraint.actuatorVelocity ?? 0.4}
                      step={0.1}
                      onChange={(v) =>
                        onUpdateConstraint(selectedConstraint.id, (c) => {
                          c.actuatorVelocity = v;
                        })
                      }
                    />
                  ) : (
                    <>
                      <NumField
                        label="Amplitude (m)"
                        value={selectedConstraint.actuatorAmplitude ?? 0.5}
                        step={0.1}
                        onChange={(v) =>
                          onUpdateConstraint(selectedConstraint.id, (c) => {
                            c.actuatorAmplitude = v;
                          })
                        }
                      />
                      <NumField
                        label="Freq (rad/s)"
                        value={selectedConstraint.actuatorFrequency ?? 3}
                        step={0.5}
                        onChange={(v) =>
                          onUpdateConstraint(selectedConstraint.id, (c) => {
                            c.actuatorFrequency = v;
                          })
                        }
                      />
                    </>
                  )}
                </div>
              </div>
            </Section>
          )}

          {selectedConstraint.kind === 'motor' && (
            <Section title="Rotary Motor">
              <div className="grid grid-cols-2 gap-2">
                <NumField
                  label="Speed ω (rad/s)"
                  value={selectedConstraint.motorTargetOmega ?? 3}
                  step={0.5}
                  onChange={(v) =>
                    onUpdateConstraint(selectedConstraint.id, (c) => {
                      c.motorTargetOmega = v;
                    })
                  }
                />
                <NumField
                  label="Max Torque (N·m)"
                  value={selectedConstraint.motorMaxTorque ?? 80}
                  min={0}
                  step={5}
                  onChange={(v) =>
                    onUpdateConstraint(selectedConstraint.id, (c) => {
                      c.motorMaxTorque = Math.max(0, v);
                    })
                  }
                />
              </div>
            </Section>
          )}

          {selectedConstraint.kind === 'slot' && (
            <Section title="Slot Track">
              <div className="grid grid-cols-2 gap-2">
                <NumField
                  label="Angle (°)"
                  value={((selectedConstraint.slotAngle ?? 0) * 180) / Math.PI}
                  step={5}
                  onChange={(v) =>
                    onUpdateConstraint(selectedConstraint.id, (c) => {
                      c.slotAngle = (v * Math.PI) / 180;
                    })
                  }
                />
                <NumField
                  label="Track Length (m)"
                  value={selectedConstraint.slotLength ?? 4}
                  min={0.5}
                  step={0.5}
                  onChange={(v) =>
                    onUpdateConstraint(selectedConstraint.id, (c) => {
                      c.slotLength = Math.max(0.5, v);
                    })
                  }
                />
              </div>
              <CheckField
                label="Keyed Slot (Lock Rotation)"
                checked={Boolean(selectedConstraint.slotKeyed)}
                onChange={(v) =>
                  onUpdateConstraint(selectedConstraint.id, (c) => {
                    c.slotKeyed = v;
                  })
                }
              />
            </Section>
          )}

          {selectedConstraint.kind === 'force' && (
            <Section title="Applied Force Vector">
              <div className="grid grid-cols-2 gap-2">
                <NumField
                  label="Fx (N)"
                  value={selectedConstraint.forceX ?? 0}
                  step={2}
                  onChange={(v) =>
                    onUpdateConstraint(selectedConstraint.id, (c) => {
                      c.forceX = v;
                    })
                  }
                />
                <NumField
                  label="Fy (N)"
                  value={selectedConstraint.forceY ?? 0}
                  step={2}
                  onChange={(v) =>
                    onUpdateConstraint(selectedConstraint.id, (c) => {
                      c.forceY = v;
                    })
                  }
                />
              </div>
              <CheckField
                label="Rotate With Body"
                checked={Boolean(selectedConstraint.forceFollowBody)}
                onChange={(v) =>
                  onUpdateConstraint(selectedConstraint.id, (c) => {
                    c.forceFollowBody = v;
                  })
                }
              />
            </Section>
          )}

          {selectedConstraint.kind === 'torque' && (
            <Section title="Applied Torque">
              <NumField
                label="Torque τ (N·m)"
                value={selectedConstraint.torqueValue ?? 15}
                step={2}
                onChange={(v) =>
                  onUpdateConstraint(selectedConstraint.id, (c) => {
                    c.torqueValue = v;
                  })
                }
              />
            </Section>
          )}
        </div>
      )}

      {/* Text Annotation Inspector */}
      {selectedAnnotation && (
        <div className="p-3 space-y-3">
          <Section title="Annotation Text">
            <input
              type="text"
              value={selectedAnnotation.text}
              onChange={(e) =>
                onUpdateAnnotation(selectedAnnotation.id, (a) => {
                  a.text = e.target.value;
                })
              }
              className="w-full px-2 py-1 bg-white border border-[#cbd5e1] rounded text-[12px]"
            />
            <div className="grid grid-cols-2 gap-2 mt-2">
              <NumField
                label="Font Size"
                value={selectedAnnotation.fontSize}
                min={10}
                max={36}
                step={1}
                onChange={(v) =>
                  onUpdateAnnotation(selectedAnnotation.id, (a) => {
                    a.fontSize = Math.max(10, Math.min(36, v));
                  })
                }
              />
              <div>
                <label className="block text-[10px] text-[#64748b] mb-0.5">Color</label>
                <input
                  type="color"
                  value={selectedAnnotation.color}
                  onChange={(e) =>
                    onUpdateAnnotation(selectedAnnotation.id, (a) => {
                      a.color = e.target.value;
                    })
                  }
                  className="w-full h-6 border border-[#cbd5e1]"
                />
              </div>
            </div>
          </Section>
        </div>
      )}

      {/* Default Workspace Quick Settings */}
      {!selectedBody && !selectedConstraint && !selectedAnnotation && selection.bodyIds.length === 0 && (
        <div className="p-3 space-y-3">
          <Section title="Gravity & Environment">
            <div className="grid grid-cols-2 gap-2">
              <NumField
                label="Gravity X (m/s²)"
                value={world.gx}
                step={0.5}
                onChange={(v) => onUpdateWorld({ gx: v })}
              />
              <NumField
                label="Gravity Y (m/s²)"
                value={world.gy}
                step={0.5}
                onChange={(v) => onUpdateWorld({ gy: v })}
              />
            </div>
            <NumField
              label="Air Resistance"
              value={world.airResistance}
              min={0}
              step={0.02}
              onChange={(v) => onUpdateWorld({ airResistance: Math.max(0, v) })}
            />
          </Section>

          <Section title="Display Vectors">
            <CheckField
              label="Velocity Vectors (Blue)"
              checked={world.showVectors.velocity}
              onChange={(v) =>
                onUpdateWorld({ showVectors: { ...world.showVectors, velocity: v } })
              }
            />
            <CheckField
              label="Acceleration Vectors (Green)"
              checked={world.showVectors.acceleration}
              onChange={(v) =>
                onUpdateWorld({ showVectors: { ...world.showVectors, acceleration: v } })
              }
            />
            <CheckField
              label="Net Force Vectors (Red)"
              checked={world.showVectors.force}
              onChange={(v) =>
                onUpdateWorld({ showVectors: { ...world.showVectors, force: v } })
              }
            />
            <CheckField
              label="Gravity Vectors (Purple)"
              checked={world.showVectors.gravity}
              onChange={(v) =>
                onUpdateWorld({ showVectors: { ...world.showVectors, gravity: v } })
              }
            />
          </Section>

          <Section title="Workspace Grid">
            <CheckField
              label="Show Grid Lines"
              checked={world.showGrid}
              onChange={(v) => onUpdateWorld({ showGrid: v })}
            />
            <CheckField
              label="Snap to Grid"
              checked={world.snapToGrid}
              onChange={(v) => onUpdateWorld({ snapToGrid: v })}
            />
            <CheckField
              label="Show Rulers"
              checked={world.showRulers}
              onChange={(v) => onUpdateWorld({ showRulers: v })}
            />
            <CheckField
              label="Show Path Traces"
              checked={world.showTrackPoints}
              onChange={(v) => onUpdateWorld({ showTrackPoints: v })}
            />
          </Section>
        </div>
      )}
    </aside>
  );
};

const Section: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="pt-2 border-t border-[#cbd5e1] space-y-1.5">
    <div className="text-[11px] font-semibold text-[#334155]">{title}</div>
    {children}
  </div>
);

const NumField: React.FC<{
  label: string;
  value: number;
  min?: number;
  max?: number;
  step?: number;
  onChange: (val: number) => void;
}> = ({ label, value, min, max, step = 0.1, onChange }) => (
  <div>
    <label className="block text-[10px] text-[#64748b] mb-0.5 truncate">{label}</label>
    <input
      type="number"
      value={Number.isFinite(value) ? Number(value.toFixed(3)) : 0}
      min={min}
      max={max}
      step={step}
      onChange={(e) => {
        const parsed = parseFloat(e.target.value);
        if (Number.isFinite(parsed)) onChange(parsed);
      }}
      className="w-full px-1.5 py-1 bg-white border border-[#cbd5e1] rounded text-[11px] font-mono-num focus:outline-none focus:border-[#2563eb]"
    />
  </div>
);

const CheckField: React.FC<{
  label: string;
  checked: boolean;
  onChange: (val: boolean) => void;
}> = ({ label, checked, onChange }) => (
  <label className="flex items-center gap-2 text-[11px] text-[#1e293b] cursor-pointer">
    <input
      type="checkbox"
      checked={checked}
      onChange={(e) => onChange(e.target.checked)}
    />
    <span>{label}</span>
  </label>
);
