import React, { useState } from 'react';
import { X } from 'lucide-react';
import {
  ControlWidget,
  PhysicsConstraint,
  RigidBody,
  ScriptRule,
  WorldSettings,
} from '../physics/types';

export type DialogKind =
  | 'gravity'
  | 'air'
  | 'accuracy'
  | 'units'
  | 'vectors'
  | 'newControl'
  | 'script'
  | 'help'
  | 'about'
  | null;

interface DialogsProps {
  activeDialog: DialogKind;
  world: WorldSettings;
  bodies: RigidBody[];
  constraints: PhysicsConstraint[];
  scripts: ScriptRule[];
  onClose: () => void;
  onUpdateWorld: (patch: Partial<WorldSettings>) => void;
  onAddControl: (ctrl: ControlWidget) => void;
  onUpdateScripts: (rules: ScriptRule[]) => void;
}

export const Dialogs: React.FC<DialogsProps> = ({
  activeDialog,
  world,
  bodies,
  constraints,
  scripts,
  onClose,
  onUpdateWorld,
  onAddControl,
  onUpdateScripts,
}) => {
  // Local form states initialized cleanly per render
  const [ctrlTarget, setCtrlTarget] = useState<'world' | 'body' | 'constraint'>('world');
  const [ctrlTargetId, setCtrlTargetId] = useState<string>('');
  const [ctrlProp, setCtrlProp] = useState<ControlWidget['property']>('gy');
  const [ctrlLabel, setCtrlLabel] = useState('Gravity Y');
  const [ctrlMin, setCtrlMin] = useState(-20);
  const [ctrlMax, setCtrlMax] = useState(0);
  const [ctrlStep, setCtrlStep] = useState(0.5);

  const [newRuleTargetType, setNewRuleTargetType] = useState<'body' | 'constraint'>('body');
  const [newRuleTargetId, setNewRuleTargetId] = useState<string>(bodies[0]?.id ?? '');
  const [newRuleProp, setNewRuleProp] = useState<string>('vy');
  const [newRuleExpr, setNewRuleExpr] = useState<string>('3 * sin(2 * t)');

  if (!activeDialog) return null;

  return (
    <div className="fixed inset-0 bg-black/35 flex items-center justify-center z-50 p-4">
      <div className="bg-[#f8fafc] border border-[#64748b] shadow-xl rounded-[3px] w-full max-w-[440px] text-[12px] text-[#111827] overflow-hidden">
        <div className="h-[28px] bg-[#1e3a8a] text-white px-3 flex items-center justify-between">
          <span className="font-semibold">
            {activeDialog === 'gravity' && 'World Gravity Settings'}
            {activeDialog === 'air' && 'Air Resistance Settings'}
            {activeDialog === 'accuracy' && 'Simulation Accuracy & Integration'}
            {activeDialog === 'units' && 'Numbers & Units'}
            {activeDialog === 'vectors' && 'Vector Display Settings'}
            {activeDialog === 'newControl' && 'Define New Control Slider'}
            {activeDialog === 'script' && 'Formula & Script Editor'}
            {activeDialog === 'help' && 'Interactive Physics Guide & Shortcuts'}
            {activeDialog === 'about' && 'About Interactive Physics Web'}
          </span>
          <button type="button" onClick={onClose} className="p-0.5 hover:bg-white/20 rounded">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 space-y-3 max-h-[75vh] overflow-y-auto">
          {activeDialog === 'gravity' && (
            <>
              <div className="space-y-1.5">
                <label className="font-semibold block">Gravity Mode</label>
                <div className="flex gap-2">
                  {(['vertical', 'planetary', 'none'] as const).map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => onUpdateWorld({ gravityMode: m })}
                      className={`px-3 py-1.5 rounded border capitalize ${
                        world.gravityMode === m
                          ? 'bg-[#2563eb] text-white border-[#1d4ed8]'
                          : 'bg-white border-[#cbd5e1]'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              {world.gravityMode === 'vertical' && (
                <div className="space-y-2">
                  <div className="flex flex-wrap gap-1.5">
                    {[
                      { label: 'Earth (-9.81)', gy: -9.81 },
                      { label: 'Moon (-1.62)', gy: -1.62 },
                      { label: 'Mars (-3.71)', gy: -3.71 },
                      { label: 'Jupiter (-24.79)', gy: -24.79 },
                    ].map((preset) => (
                      <button
                        key={preset.label}
                        type="button"
                        onClick={() => onUpdateWorld({ gx: 0, gy: preset.gy })}
                        className="px-2 py-1 bg-white border border-[#cbd5e1] rounded hover:bg-[#e2e8f0]"
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>
                  <div className="grid grid-cols-2 gap-3 pt-1">
                    <div>
                      <label className="block text-[11px] text-[#475569]">Gravity X (m/s²)</label>
                      <input
                        type="number"
                        step={0.1}
                        value={world.gx}
                        onChange={(e) => onUpdateWorld({ gx: parseFloat(e.target.value) || 0 })}
                        className="w-full px-2 py-1 border border-[#cbd5e1] rounded bg-white font-mono-num"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-[#475569]">Gravity Y (m/s²)</label>
                      <input
                        type="number"
                        step={0.1}
                        value={world.gy}
                        onChange={(e) => onUpdateWorld({ gy: parseFloat(e.target.value) || 0 })}
                        className="w-full px-2 py-1 border border-[#cbd5e1] rounded bg-white font-mono-num"
                      />
                    </div>
                  </div>
                </div>
              )}

              {world.gravityMode === 'planetary' && (
                <div>
                  <label className="block text-[11px] text-[#475569]">Gravitational Constant G</label>
                  <input
                    type="number"
                    step={0.1}
                    value={world.gravityG}
                    onChange={(e) => onUpdateWorld({ gravityG: parseFloat(e.target.value) || 0 })}
                    className="w-full px-2 py-1 border border-[#cbd5e1] rounded bg-white font-mono-num"
                  />
                </div>
              )}
            </>
          )}

          {activeDialog === 'air' && (
            <div className="space-y-3">
              <div className="flex gap-2">
                {[
                  { label: 'None (0)', val: 0 },
                  { label: 'Low (0.02)', val: 0.02 },
                  { label: 'Medium (0.15)', val: 0.15 },
                  { label: 'High (0.60)', val: 0.6 },
                ].map((p) => (
                  <button
                    key={p.label}
                    type="button"
                    onClick={() => onUpdateWorld({ airResistance: p.val })}
                    className="px-2 py-1 bg-white border border-[#cbd5e1] rounded hover:bg-[#e2e8f0]"
                  >
                    {p.label}
                  </button>
                ))}
              </div>
              <div>
                <label className="block text-[11px] text-[#475569] mb-1">Drag Coefficient (N·s/m)</label>
                <input
                  type="number"
                  min={0}
                  step={0.01}
                  value={world.airResistance}
                  onChange={(e) => onUpdateWorld({ airResistance: Math.max(0, parseFloat(e.target.value) || 0) })}
                  className="w-full px-2 py-1 border border-[#cbd5e1] rounded bg-white font-mono-num"
                />
              </div>
            </div>
          )}

          {activeDialog === 'accuracy' && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] text-[#475569] mb-1">Time Step dt (s)</label>
                <input
                  type="number"
                  min={0.001}
                  max={0.05}
                  step={0.002}
                  value={world.dt}
                  onChange={(e) => onUpdateWorld({ dt: Math.max(0.001, parseFloat(e.target.value) || 1 / 60) })}
                  className="w-full px-2 py-1 border border-[#cbd5e1] rounded bg-white font-mono-num"
                />
              </div>
              <div>
                <label className="block text-[11px] text-[#475569] mb-1">Substeps per Frame</label>
                <input
                  type="number"
                  min={1}
                  max={20}
                  step={1}
                  value={world.substeps}
                  onChange={(e) => onUpdateWorld({ substeps: Math.max(1, parseInt(e.target.value, 10) || 6) })}
                  className="w-full px-2 py-1 border border-[#cbd5e1] rounded bg-white font-mono-num"
                />
              </div>
              <div>
                <label className="block text-[11px] text-[#475569] mb-1">Solver Iterations</label>
                <input
                  type="number"
                  min={2}
                  max={40}
                  step={1}
                  value={world.solverIterations}
                  onChange={(e) => onUpdateWorld({ solverIterations: Math.max(2, parseInt(e.target.value, 10) || 10) })}
                  className="w-full px-2 py-1 border border-[#cbd5e1] rounded bg-white font-mono-num"
                />
              </div>
              <div>
                <label className="block text-[11px] text-[#475569] mb-1">Auto-Stop Time (s, empty=off)</label>
                <input
                  type="number"
                  min={0}
                  step={0.5}
                  value={world.autoStopTime ?? ''}
                  onChange={(e) => {
                    const v = e.target.value.trim();
                    onUpdateWorld({ autoStopTime: v === '' ? null : Math.max(0, parseFloat(v) || 0) });
                  }}
                  className="w-full px-2 py-1 border border-[#cbd5e1] rounded bg-white font-mono-num"
                />
              </div>
            </div>
          )}

          {activeDialog === 'units' && (
            <div className="space-y-3">
              <div>
                <label className="block text-[11px] text-[#475569] mb-1">Unit System</label>
                <select
                  value={world.unitSystem}
                  onChange={(e) => onUpdateWorld({ unitSystem: e.target.value as WorldSettings['unitSystem'] })}
                  className="w-full px-2 py-1 border border-[#cbd5e1] rounded bg-white"
                >
                  <option value="SI">SI (meters, kilograms, seconds, Newtons)</option>
                  <option value="CGS">CGS (cm, grams, seconds)</option>
                  <option value="Imperial">English (feet, pounds, seconds)</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-[#475569] mb-1">Decimal Precision</label>
                  <input
                    type="number"
                    min={0}
                    max={5}
                    value={world.precision}
                    onChange={(e) => onUpdateWorld({ precision: Math.max(0, Math.min(5, parseInt(e.target.value, 10) || 2)) })}
                    className="w-full px-2 py-1 border border-[#cbd5e1] rounded bg-white font-mono-num"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-[#475569] mb-1">Grid Spacing (m)</label>
                  <input
                    type="number"
                    min={0.25}
                    step={0.25}
                    value={world.gridSpacing}
                    onChange={(e) => onUpdateWorld({ gridSpacing: Math.max(0.25, parseFloat(e.target.value) || 1) })}
                    className="w-full px-2 py-1 border border-[#cbd5e1] rounded bg-white font-mono-num"
                  />
                </div>
              </div>
            </div>
          )}

          {activeDialog === 'vectors' && (
            <div className="space-y-2.5">
              {(
                [
                  { key: 'velocity', label: 'Velocity Vectors (Blue)' },
                  { key: 'acceleration', label: 'Acceleration Vectors (Green)' },
                  { key: 'force', label: 'Total Force Vectors (Red)' },
                  { key: 'gravity', label: 'Gravity Force Vectors (Purple)' },
                ] as const
              ).map((item) => (
                <label key={item.key} className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={world.showVectors[item.key]}
                    onChange={(e) =>
                      onUpdateWorld({
                        showVectors: { ...world.showVectors, [item.key]: e.target.checked },
                      })
                    }
                  />
                  <span>{item.label}</span>
                </label>
              ))}
              <div>
                <label className="block text-[11px] text-[#475569] mb-1">Vector Length Scale</label>
                <input
                  type="range"
                  min={0.05}
                  max={1.0}
                  step={0.05}
                  value={world.vectorScale}
                  onChange={(e) => onUpdateWorld({ vectorScale: parseFloat(e.target.value) })}
                  className="w-full accent-[#2563eb]"
                />
              </div>
            </div>
          )}

          {activeDialog === 'newControl' && (
            <div className="space-y-2.5">
              <div>
                <label className="block text-[11px] text-[#475569] mb-1">Target Category</label>
                <select
                  value={ctrlTarget}
                  onChange={(e) => {
                    const t = e.target.value as 'world' | 'body' | 'constraint';
                    setCtrlTarget(t);
                    if (t === 'world') {
                      setCtrlProp('gy');
                      setCtrlLabel('Gravity Y');
                    } else if (t === 'body') {
                      setCtrlTargetId(bodies[0]?.id ?? '');
                      setCtrlProp('mass');
                      setCtrlLabel('Mass');
                      setCtrlMin(0.5);
                      setCtrlMax(20);
                    } else {
                      setCtrlTargetId(constraints[0]?.id ?? '');
                      setCtrlProp('stiffness');
                      setCtrlLabel('Stiffness k');
                      setCtrlMin(0);
                      setCtrlMax(200);
                    }
                  }}
                  className="w-full px-2 py-1 border border-[#cbd5e1] rounded bg-white"
                >
                  <option value="world">World Environment</option>
                  <option value="body">Rigid Body</option>
                  <option value="constraint">Spring / Motor / Force</option>
                </select>
              </div>

              {ctrlTarget !== 'world' && (
                <div>
                  <label className="block text-[11px] text-[#475569] mb-1">Target Object</label>
                  <select
                    value={ctrlTargetId}
                    onChange={(e) => setCtrlTargetId(e.target.value)}
                    className="w-full px-2 py-1 border border-[#cbd5e1] rounded bg-white"
                  >
                    {(ctrlTarget === 'body' ? bodies : constraints).map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] text-[#475569] mb-1">Property</label>
                  <select
                    value={ctrlProp}
                    onChange={(e) => setCtrlProp(e.target.value as ControlWidget['property'])}
                    className="w-full px-2 py-1 border border-[#cbd5e1] rounded bg-white"
                  >
                    {ctrlTarget === 'world' && (
                      <>
                        <option value="gy">Gravity Y</option>
                        <option value="gx">Gravity X</option>
                        <option value="airResistance">Air Resistance</option>
                      </>
                    )}
                    {ctrlTarget === 'body' && (
                      <>
                        <option value="mass">Mass (kg)</option>
                        <option value="restitution">Elasticity (e)</option>
                        <option value="kineticFriction">Friction μk</option>
                        <option value="charge">Charge q</option>
                      </>
                    )}
                    {ctrlTarget === 'constraint' && (
                      <>
                        <option value="stiffness">Spring k</option>
                        <option value="damping">Damping c</option>
                        <option value="motorTargetOmega">Motor Speed ω</option>
                        <option value="forceX">Force X</option>
                        <option value="forceY">Force Y</option>
                      </>
                    )}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-[#475569] mb-1">Label</label>
                  <input
                    type="text"
                    value={ctrlLabel}
                    onChange={(e) => setCtrlLabel(e.target.value)}
                    className="w-full px-2 py-1 border border-[#cbd5e1] rounded bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[10px] text-[#475569]">Min</label>
                  <input
                    type="number"
                    value={ctrlMin}
                    onChange={(e) => setCtrlMin(parseFloat(e.target.value) || 0)}
                    className="w-full px-2 py-1 border border-[#cbd5e1] rounded bg-white font-mono-num"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-[#475569]">Max</label>
                  <input
                    type="number"
                    value={ctrlMax}
                    onChange={(e) => setCtrlMax(parseFloat(e.target.value) || 10)}
                    className="w-full px-2 py-1 border border-[#cbd5e1] rounded bg-white font-mono-num"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-[#475569]">Step</label>
                  <input
                    type="number"
                    step={0.05}
                    value={ctrlStep}
                    onChange={(e) => setCtrlStep(parseFloat(e.target.value) || 0.1)}
                    className="w-full px-2 py-1 border border-[#cbd5e1] rounded bg-white font-mono-num"
                  />
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  onAddControl({
                    id: `ctrl_${Date.now()}`,
                    label: ctrlLabel,
                    targetType: ctrlTarget,
                    targetId: ctrlTarget === 'world' ? null : ctrlTargetId || null,
                    property: ctrlProp,
                    min: ctrlMin,
                    max: ctrlMax,
                    step: ctrlStep,
                    unit: '',
                    x: 20,
                    y: 20,
                  });
                  onClose();
                }}
                className="w-full py-1.5 bg-[#2563eb] text-white rounded font-medium hover:bg-[#1d4ed8]"
              >
                Create Control Slider
              </button>
            </div>
          )}

          {activeDialog === 'script' && (
            <div className="space-y-3">
              <p className="text-[11px] text-[#475569]">
                Bind live math formulas using variables <code className="font-mono-num bg-[#e2e8f0] px-1">t</code>,{' '}
                <code className="font-mono-num bg-[#e2e8f0] px-1">x</code>,{' '}
                <code className="font-mono-num bg-[#e2e8f0] px-1">y</code>,{' '}
                <code className="font-mono-num bg-[#e2e8f0] px-1">vx</code>,{' '}
                <code className="font-mono-num bg-[#e2e8f0] px-1">vy</code> and functions{' '}
                <code className="font-mono-num bg-[#e2e8f0] px-1">sin()</code>,{' '}
                <code className="font-mono-num bg-[#e2e8f0] px-1">cos()</code>,{' '}
                <code className="font-mono-num bg-[#e2e8f0] px-1">abs()</code>.
              </p>
              <div className="grid grid-cols-2 gap-2">
                <select
                  value={newRuleTargetType}
                  onChange={(e) => {
                    const t = e.target.value as 'body' | 'constraint';
                    setNewRuleTargetType(t);
                    setNewRuleTargetId(t === 'body' ? bodies[0]?.id ?? '' : constraints[0]?.id ?? '');
                    setNewRuleProp(t === 'body' ? 'vy' : 'motorTargetOmega');
                  }}
                  className="px-2 py-1 border border-[#cbd5e1] rounded bg-white"
                >
                  <option value="body">Body</option>
                  <option value="constraint">Constraint</option>
                </select>
                <select
                  value={newRuleTargetId}
                  onChange={(e) => setNewRuleTargetId(e.target.value)}
                  className="px-2 py-1 border border-[#cbd5e1] rounded bg-white"
                >
                  {(newRuleTargetType === 'body' ? bodies : constraints).map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newRuleProp}
                  onChange={(e) => setNewRuleProp(e.target.value)}
                  placeholder="Property (vx, vy, omega...)"
                  className="w-1/3 px-2 py-1 border border-[#cbd5e1] rounded bg-white font-mono-num"
                />
                <input
                  type="text"
                  value={newRuleExpr}
                  onChange={(e) => setNewRuleExpr(e.target.value)}
                  placeholder="Expression e.g. 4*sin(2*t)"
                  className="flex-1 px-2 py-1 border border-[#cbd5e1] rounded bg-white font-mono-num"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (!newRuleTargetId) return;
                    onUpdateScripts([
                      ...scripts,
                      {
                        id: `scr_${Date.now()}`,
                        name: `${newRuleProp} = ${newRuleExpr}`,
                        enabled: true,
                        targetType: newRuleTargetType,
                        targetId: newRuleTargetId,
                        property: newRuleProp,
                        expression: newRuleExpr,
                      },
                    ]);
                  }}
                  className="px-3 py-1 bg-[#2563eb] text-white rounded font-medium"
                >
                  Add
                </button>
              </div>

              {scripts.length > 0 && (
                <div className="border-t border-[#cbd5e1] pt-2 space-y-1.5">
                  {scripts.map((r) => (
                    <div
                      key={r.id}
                      className="flex items-center justify-between bg-white px-2 py-1 border border-[#cbd5e1] rounded font-mono-num text-[11px]"
                    >
                      <span>{r.name}</span>
                      <button
                        type="button"
                        onClick={() => onUpdateScripts(scripts.filter((x) => x.id !== r.id))}
                        className="text-[#dc2626] hover:underline"
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeDialog === 'help' && (
            <div className="space-y-2 text-[12px] leading-relaxed">
              <p><strong>Run / Stop:</strong> Press <kbd className="px-1 bg-[#e2e8f0] rounded">Space</kbd> or click Run.</p>
              <p><strong>Live Grab:</strong> While running, use the Select arrow to grab and fling any object.</p>
              <p><strong>Draw Shapes:</strong> Pick Rectangle, Square, Circle, Gear, Pulley, or Polygon on the left palette.</p>
              <p><strong>Joints & Links:</strong> Click overlapping bodies with Pin/Rigid Joint, or drag between bodies with Spring, Damper, Rope, Rod, or Actuator.</p>
              <p><strong>Pulleys & Gears:</strong> Draw a Rope near a Pulley to automatically route over it. Select two Gears and click Object → Mesh Touching Gears.</p>
              <p><strong>Tape Scrubber:</strong> Pause the simulation and drag the bottom Tape slider to inspect any past frame.</p>
            </div>
          )}

          {activeDialog === 'about' && (
            <div className="space-y-2">
              <p className="font-semibold text-[14px]">Interactive Physics Web Laboratory</p>
              <p className="text-[#475569]">
                A faithful browser-based 2D rigid-body physics simulator featuring Sequential Impulse collision & constraint solving, Hooke springs, dampers, pulley ropes, meshed gears, rotary motors, actuators, slot rails, live vector arrows, and real-time graphing meters.
              </p>
            </div>
          )}
        </div>

        <div className="px-4 py-2 bg-[#ece9d8] border-t border-[#cbd5e1] flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1 bg-white border border-[#94a3b8] rounded hover:bg-[#e2e8f0] font-medium"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
