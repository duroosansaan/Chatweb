import React from 'react';
import { ToolId } from '../physics/types';

export const ToolIcon: React.FC<{ tool: ToolId; className?: string }> = ({
  tool,
  className = 'w-4 h-4',
}) => {
  const props = {
    viewBox: '0 0 20 20',
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 1.5,
    strokeLinecap: 'round' as const,
    strokeLinejoin: 'round' as const,
    className,
  };

  switch (tool) {
    case 'select':
      return (
        <svg {...props}>
          <path d="M5 3L5 15L8.5 11.8L11.5 17L13.4 16L10.4 10.8L15 10.5L5 3Z" fill="currentColor" stroke="none" />
        </svg>
      );
    case 'rotate':
      return (
        <svg {...props}>
          <path d="M15.5 8A5.5 5.5 0 1 0 14 14" />
          <path d="M15.5 4.5V8H12" />
          <circle cx="10" cy="10" r="1.5" fill="currentColor" stroke="none" />
        </svg>
      );
    case 'zoom':
      return (
        <svg {...props}>
          <circle cx="8.5" cy="8.5" r="5" />
          <path d="M12.2 12.2L16.5 16.5" strokeWidth="2" />
          <path d="M6.5 8.5H10.5M8.5 6.5V10.5" />
        </svg>
      );
    case 'pan':
      return (
        <svg {...props}>
          <path d="M10 3V17M3 10H17" />
          <path d="M10 3L8 5M10 3L12 5M10 17L8 15M10 17L12 15M3 10L5 8M3 10L5 12M17 10L15 8M17 10L15 12" />
        </svg>
      );
    case 'rect':
      return (
        <svg {...props}>
          <rect x="3" y="5.5" width="14" height="9" fill="#93c5fd" fillOpacity="0.6" />
        </svg>
      );
    case 'square':
      return (
        <svg {...props}>
          <rect x="4.5" y="4.5" width="11" height="11" fill="#93c5fd" fillOpacity="0.6" />
        </svg>
      );
    case 'circle':
      return (
        <svg {...props}>
          <circle cx="10" cy="10" r="6" fill="#93c5fd" fillOpacity="0.6" />
        </svg>
      );
    case 'polygon':
      return (
        <svg {...props}>
          <polygon points="10,3.5 16.5,8 14,16 6,16 3.5,8" fill="#93c5fd" fillOpacity="0.6" />
        </svg>
      );
    case 'point':
      return (
        <svg {...props}>
          <circle cx="10" cy="10" r="2.2" fill="currentColor" />
          <path d="M10 4V6.5M10 13.5V16M4 10H6.5M13.5 10H16" />
        </svg>
      );
    case 'anchor':
      return (
        <svg {...props}>
          <path d="M10 3.5V16.5M6.5 6.5H13.5" />
          <path d="M5 12C5 15 7.5 16.5 10 16.5C12.5 16.5 15 15 15 12" />
          <circle cx="10" cy="3.5" r="1.5" />
        </svg>
      );
    case 'pin':
      return (
        <svg {...props}>
          <circle cx="10" cy="10" r="4.5" />
          <circle cx="10" cy="10" r="1.5" fill="currentColor" />
        </svg>
      );
    case 'weld':
      return (
        <svg {...props}>
          <rect x="4" y="4" width="12" height="12" rx="1" />
          <path d="M5.5 5.5L14.5 14.5M14.5 5.5L5.5 14.5" />
        </svg>
      );
    case 'hslot':
      return (
        <svg {...props}>
          <rect x="2.5" y="8" width="15" height="4" rx="2" />
          <circle cx="10" cy="10" r="2.2" fill="currentColor" />
        </svg>
      );
    case 'vslot':
      return (
        <svg {...props}>
          <rect x="8" y="2.5" width="4" height="15" rx="2" />
          <circle cx="10" cy="10" r="2.2" fill="currentColor" />
        </svg>
      );
    case 'slot':
      return (
        <svg {...props}>
          <path d="M4.5 15.5L15.5 4.5" strokeWidth="4.5" strokeOpacity="0.25" />
          <path d="M4.5 15.5L15.5 4.5" />
          <circle cx="10" cy="10" r="2.2" fill="currentColor" />
        </svg>
      );
    case 'rod':
      return (
        <svg {...props}>
          <line x1="4.5" y1="15.5" x2="15.5" y2="4.5" strokeWidth="2" />
          <circle cx="4.5" cy="15.5" r="2" fill="#fff" />
          <circle cx="15.5" cy="4.5" r="2" fill="#fff" />
        </svg>
      );
    case 'spring':
      return (
        <svg {...props}>
          <path d="M4 16L6 14L4.5 11.5L9.5 11L6.5 8L12 7.5L9 4.5L14 4L16 2" />
          <circle cx="3.5" cy="16.5" r="1.3" fill="currentColor" />
          <circle cx="16.5" cy="2.5" r="1.3" fill="currentColor" />
        </svg>
      );
    case 'damper':
      return (
        <svg {...props}>
          <path d="M3 17L7.5 12.5" />
          <path d="M6 10L10 14L14 10L10 6" />
          <path d="M8.5 11.5L12.5 7.5M12.5 7.5L17 3" />
          <path d="M9.5 6.5L13.5 10.5" />
        </svg>
      );
    case 'rope':
      return (
        <svg {...props}>
          <path d="M4 15.5C6.5 10 12 13 16 4.5" />
          <circle cx="4" cy="15.5" r="1.6" fill="currentColor" />
          <circle cx="16" cy="4.5" r="1.6" fill="currentColor" />
        </svg>
      );
    case 'actuator':
      return (
        <svg {...props}>
          <rect x="4" y="8" width="7" height="4" transform="rotate(-45 7.5 10)" fill="#cbd5e1" />
          <line x1="10.5" y1="9.5" x2="16" y2="4" strokeWidth="2" />
          <circle cx="4" cy="16" r="1.5" fill="currentColor" />
          <circle cx="16" cy="4" r="1.5" fill="currentColor" />
        </svg>
      );
    case 'motor':
      return (
        <svg {...props}>
          <circle cx="10" cy="10" r="5" />
          <path d="M10 2.5A7.5 7.5 0 0 1 17.5 10" />
          <path d="M17.5 7.5V10.5H14.5" />
          <circle cx="10" cy="10" r="1.5" fill="currentColor" />
        </svg>
      );
    case 'gear':
      return (
        <svg {...props}>
          <circle cx="10" cy="10" r="4.2" fill="#93c5fd" fillOpacity="0.5" />
          <circle cx="10" cy="10" r="1.6" />
          <path d="M10 3V5M10 15V17M3 10H5M15 10H17M5 5L6.5 6.5M13.5 13.5L15 15M15 5L13.5 6.5M6.5 13.5L5 15" />
        </svg>
      );
    case 'pulley':
      return (
        <svg {...props}>
          <circle cx="10" cy="8.5" r="4.5" fill="#cbd5e1" fillOpacity="0.6" />
          <circle cx="10" cy="8.5" r="1.4" fill="currentColor" />
          <path d="M5.5 8.5V16.5M14.5 8.5V16.5" />
        </svg>
      );
    case 'force':
      return (
        <svg {...props}>
          <line x1="3.5" y1="15.5" x2="15.5" y2="4.5" stroke="#dc2626" strokeWidth="2" />
          <path d="M10.5 4.5H15.5V9.5" stroke="#dc2626" strokeWidth="2" />
        </svg>
      );
    case 'torque':
      return (
        <svg {...props}>
          <path d="M15 8A5.5 5.5 0 1 0 12 15.5" stroke="#dc2626" strokeWidth="1.8" />
          <path d="M15.5 4.5V8.5H11.5" stroke="#dc2626" strokeWidth="1.8" />
        </svg>
      );
    case 'thruster':
      return (
        <svg {...props}>
          <path d="M14 6L8 12L5 11L11 5L14 6Z" fill="#cbd5e1" />
          <path d="M6.5 13.5L3.5 16.5M8 14L6 17M5.5 12L3 14" stroke="#ea580c" strokeWidth="1.6" />
        </svg>
      );
    case 'text':
      return (
        <svg {...props}>
          <path d="M5 5H15M10 5V16M7.5 16H12.5" strokeWidth="1.8" />
        </svg>
      );
  }
};
