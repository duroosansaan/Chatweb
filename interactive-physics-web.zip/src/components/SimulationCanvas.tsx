import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  distToSegment,
  getRectVertices,
  localToWorld,
  pointInBody,
  recalcBodyMassProperties,
  vLen,
  vSub,
  worldToLocal,
} from '../physics/math';
import { ActiveDragSpring } from '../physics/engine';
import { createBody, nextId } from '../physics/presets';
import {
  CameraState,
  PhysicsConstraint,
  RigidBody,
  SimulationState,
  TextAnnotation,
  ToolId,
  Vec2,
} from '../physics/types';

export interface SelectionState {
  bodyIds: string[];
  constraintId: string | null;
  annotationId: string | null;
}

interface SimulationCanvasProps {
  simRef: React.MutableRefObject<SimulationState>;
  cameraRef: React.MutableRefObject<CameraState>;
  dragSpringRef: React.MutableRefObject<ActiveDragSpring | null>;
  isRunning: boolean;
  activeTool: ToolId;
  selection: SelectionState;
  renderVersion: number;
  onSelect: (sel: SelectionState) => void;
  onCommitMutation: (pushUndo?: boolean) => void;
  onChangeTool: (tool: ToolId) => void;
  onCursorMove: (worldPos: Vec2) => void;
  onRequestTextPrompt: (worldPos: Vec2) => void;
}

type DragMode =
  | { type: 'none' }
  | { type: 'pan'; startScreen: Vec2; startPan: Vec2 }
  | { type: 'moveBodies'; startWorld: Vec2; initialPos: Map<string, Vec2> }
  | { type: 'springGrab'; bodyId: string }
  | { type: 'rotateBody'; bodyId: string; startAngle: number; pointerStartAngle: number }
  | {
      type: 'resizeBody';
      bodyId: string;
      handle: string;
      startWorld: Vec2;
      origW: number;
      origH: number;
      origR: number;
    }
  | { type: 'marquee'; startWorld: Vec2; currentWorld: Vec2 }
  | { type: 'drawShape'; shapeTool: 'rect' | 'square' | 'circle' | 'gear' | 'pulley'; startWorld: Vec2; currentWorld: Vec2 }
  | {
      type: 'drawLink';
      linkTool: 'spring' | 'damper' | 'rope' | 'rod' | 'actuator' | 'slot' | 'force';
      startWorld: Vec2;
      currentWorld: Vec2;
      startBodyId: string | null;
      startLocal: Vec2;
    };

export const SimulationCanvas: React.FC<SimulationCanvasProps> = ({
  simRef,
  cameraRef,
  dragSpringRef,
  isRunning,
  activeTool,
  selection,
  renderVersion,
  onSelect,
  onCommitMutation,
  onChangeTool,
  onCursorMove,
  onRequestTextPrompt,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const dragRef = useRef<DragMode>({ type: 'none' });
  const polyPointsRef = useRef<Vec2[]>([]);
  const [polyCount, setPolyCount] = useState(0);
  const [hoverWorld, setHoverWorld] = useState<Vec2>({ x: 0, y: 0 });
  const [canvasSize, setCanvasSize] = useState({ w: 800, h: 600 });

  const showRulers = simRef.current.world.showRulers;
  const rulerOffset = showRulers ? 22 : 0;

  // Screen <-> World conversions (relative to canvas element top-left)
  const screenToWorld = useCallback(
    (sx: number, sy: number): Vec2 => {
      const cam = cameraRef.current;
      const cx = canvasSize.w / 2;
      const cy = canvasSize.h / 2;
      return {
        x: cam.panX + (sx - cx) / cam.ppm,
        y: cam.panY - (sy - cy) / cam.ppm,
      };
    },
    [cameraRef, canvasSize]
  );

  const worldToScreen = useCallback(
    (wx: number, wy: number): Vec2 => {
      const cam = cameraRef.current;
      const cx = canvasSize.w / 2;
      const cy = canvasSize.h / 2;
      return {
        x: cx + (wx - cam.panX) * cam.ppm,
        y: cy - (wy - cam.panY) * cam.ppm,
      };
    },
    [cameraRef, canvasSize]
  );

  const maybeSnap = useCallback(
    (pt: Vec2): Vec2 => {
      const w = simRef.current.world;
      if (!w.snapToGrid) return pt;
      const step = Math.max(0.05, w.gridSpacing * 0.5);
      return {
        x: Math.round(pt.x / step) * step,
        y: Math.round(pt.y / step) * step,
      };
    },
    [simRef]
  );

  // ResizeObserver for crisp DPR canvas sizing
  useEffect(() => {
    const el = canvasRef.current;
    if (!el) return;
    const obs = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        if (width > 0 && height > 0) {
          setCanvasSize({ w: width, h: height });
        }
      }
    });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  // Hit-testing helpers
  const findTopBodyAt = useCallback(
    (worldPt: Vec2, tolMeters: number): RigidBody | null => {
      const bodies = simRef.current.bodies;
      for (let i = bodies.length - 1; i >= 0; i--) {
        if (pointInBody(bodies[i], worldPt, tolMeters)) {
          return bodies[i];
        }
      }
      return null;
    },
    [simRef]
  );

  const findAllBodiesAt = useCallback(
    (worldPt: Vec2, tolMeters: number): RigidBody[] => {
      const bodies = simRef.current.bodies;
      const res: RigidBody[] = [];
      for (let i = bodies.length - 1; i >= 0; i--) {
        if (pointInBody(bodies[i], worldPt, tolMeters)) {
          res.push(bodies[i]);
        }
      }
      return res;
    },
    [simRef]
  );

  const findConstraintAt = useCallback(
    (worldPt: Vec2, tolMeters: number): PhysicsConstraint | null => {
      const { constraints, bodies } = simRef.current;
      const map = new Map(bodies.map((b) => [b.id, b]));
      for (let i = constraints.length - 1; i >= 0; i--) {
        const c = constraints[i];
        const bA = c.bodyAId ? map.get(c.bodyAId) ?? null : null;
        const bB = c.bodyBId ? map.get(c.bodyBId) ?? null : null;
        const pA = bA ? localToWorld(bA, c.localA) : c.localA;
        const pB = bB ? localToWorld(bB, c.localB) : c.localB;

        if (c.kind === 'pin' || c.kind === 'weld' || c.kind === 'motor' || c.kind === 'torque') {
          if (vLen(vSub(worldPt, pA)) <= tolMeters * 1.4) return c;
        } else if (c.kind === 'force') {
          const tip = {
            x: pA.x + (c.forceX ?? 0) * 0.04,
            y: pA.y + (c.forceY ?? 0) * 0.04,
          };
          if (distToSegment(worldPt, pA, tip) <= tolMeters) return c;
        } else {
          if (distToSegment(worldPt, pA, pB) <= tolMeters) return c;
        }
      }
      return null;
    },
    [simRef]
  );

  const findAnnotationAt = useCallback(
    (worldPt: Vec2): TextAnnotation | null => {
      const anns = simRef.current.annotations;
      const ppm = cameraRef.current.ppm;
      for (let i = anns.length - 1; i >= 0; i--) {
        const a = anns[i];
        const w = Math.max(1.2, (a.text.length * a.fontSize * 0.6) / ppm);
        const h = (a.fontSize * 1.4) / ppm;
        if (
          worldPt.x >= a.x - 0.15 &&
          worldPt.x <= a.x + w &&
          worldPt.y <= a.y + 0.15 &&
          worldPt.y >= a.y - h
        ) {
          return a;
        }
      }
      return null;
    },
    [simRef, cameraRef]
  );

  const hitTestResizeHandle = useCallback(
    (body: RigidBody, sx: number, sy: number): string | null => {
      if (body.shape === 'point') return null;
      const center = worldToScreen(body.x, body.y);
      const ppm = cameraRef.current.ppm;

      if (body.shape === 'circle' || body.shape === 'gear' || body.shape === 'pulley') {
        const rPx = body.radius * ppm;
        const rotHandle = { x: center.x, y: center.y - rPx - 22 };
        if (Math.hypot(sx - rotHandle.x, sy - rotHandle.y) <= 9) return 'rot';
        const cardinal = [
          { id: 'e', x: center.x + rPx, y: center.y },
          { id: 'w', x: center.x - rPx, y: center.y },
          { id: 'n', x: center.x, y: center.y - rPx },
          { id: 's', x: center.x, y: center.y + rPx },
        ];
        for (const h of cardinal) {
          if (Math.hypot(sx - h.x, sy - h.y) <= 8) return h.id;
        }
        return null;
      }

      if (body.shape === 'rect') {
        const hw = (body.width * ppm) / 2;
        const hh = (body.height * ppm) / 2;
        const cos = Math.cos(-body.angle);
        const sin = Math.sin(-body.angle);
        const toScreenHandle = (lx: number, ly: number) => ({
          x: center.x + lx * cos - ly * sin,
          y: center.y + lx * sin + ly * cos,
        });
        const rotPt = toScreenHandle(0, -hh - 22);
        if (Math.hypot(sx - rotPt.x, sy - rotPt.y) <= 9) return 'rot';
        const handles = [
          { id: 'nw', p: toScreenHandle(-hw, -hh) },
          { id: 'ne', p: toScreenHandle(hw, -hh) },
          { id: 'se', p: toScreenHandle(hw, hh) },
          { id: 'sw', p: toScreenHandle(-hw, hh) },
        ];
        for (const h of handles) {
          if (Math.hypot(sx - h.p.x, sy - h.p.y) <= 8) return h.id;
        }
      }
      return null;
    },
    [cameraRef, worldToScreen]
  );

  // Finalize polygon drawing
  const finishPolygon = useCallback(() => {
    const pts = polyPointsRef.current;
    if (pts.length >= 3) {
      let cx = 0;
      let cy = 0;
      for (const p of pts) {
        cx += p.x;
        cy += p.y;
      }
      cx /= pts.length;
      cy /= pts.length;
      const localPts = pts.map((p) => ({ x: p.x - cx, y: p.y - cy }));
      const body = createBody({
        shape: 'polygon',
        x: cx,
        y: cy,
        vertices: localPts,
        name: `Polygon ${simRef.current.bodies.length + 1}`,
      });
      simRef.current.bodies.push(body);
      onSelect({ bodyIds: [body.id], constraintId: null, annotationId: null });
      onCommitMutation(true);
    }
    polyPointsRef.current = [];
    setPolyCount(0);
  }, [onCommitMutation, onSelect, simRef]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (activeTool === 'polygon') {
        if (e.key === 'Enter') {
          finishPolygon();
        } else if (e.key === 'Escape') {
          polyPointsRef.current = [];
          setPolyCount(0);
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [activeTool, finishPolygon]);

  // Reset polygon points when leaving polygon tool
  useEffect(() => {
    if (activeTool !== 'polygon' && polyPointsRef.current.length > 0) {
      polyPointsRef.current = [];
      setPolyCount(0);
    }
  }, [activeTool]);

  // Pointer Down
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.setPointerCapture(e.pointerId);

    const rect = canvas.getBoundingClientRect();
    const sx = e.clientX - rect.left;
    const sy = e.clientY - rect.top;
    const rawWorld = screenToWorld(sx, sy);
    const worldPt = maybeSnap(rawWorld);
    const tol = 11 / cameraRef.current.ppm;

    // Middle mouse or Pan tool or Space+drag
    if (e.button === 1 || activeTool === 'pan') {
      dragRef.current = {
        type: 'pan',
        startScreen: { x: sx, y: sy },
        startPan: { x: cameraRef.current.panX, y: cameraRef.current.panY },
      };
      return;
    }

    if (activeTool === 'zoom') {
      const factor = e.altKey ? 0.8 : 1.25;
      const cam = cameraRef.current;
      const newPpm = Math.max(12, Math.min(240, cam.ppm * factor));
      cam.ppm = newPpm;
      cam.panX = rawWorld.x - (sx - canvasSize.w / 2) / newPpm;
      cam.panY = rawWorld.y + (sy - canvasSize.h / 2) / newPpm;
      onCommitMutation(false);
      return;
    }

    if (activeTool === 'text') {
      onRequestTextPrompt(worldPt);
      return;
    }

    if (activeTool === 'point') {
      const ptBody = createBody({
        shape: 'point',
        x: worldPt.x,
        y: worldPt.y,
        radius: 0.12,
        name: `Point ${simRef.current.bodies.length + 1}`,
        fillColor: '#1d4ed8',
      });
      simRef.current.bodies.push(ptBody);
      onSelect({ bodyIds: [ptBody.id], constraintId: null, annotationId: null });
      onCommitMutation(true);
      return;
    }

    if (activeTool === 'polygon') {
      const pts = polyPointsRef.current;
      if (pts.length >= 3 && vLen(vSub(worldPt, pts[0])) <= tol * 1.4) {
        finishPolygon();
        return;
      }
      pts.push(worldPt);
      setPolyCount(pts.length);
      return;
    }

    if (
      activeTool === 'rect' ||
      activeTool === 'square' ||
      activeTool === 'circle' ||
      activeTool === 'gear' ||
      activeTool === 'pulley'
    ) {
      dragRef.current = {
        type: 'drawShape',
        shapeTool: activeTool,
        startWorld: worldPt,
        currentWorld: worldPt,
      };
      return;
    }

    // One-click body/constraint tools
    if (activeTool === 'anchor') {
      const hit = findTopBodyAt(rawWorld, tol);
      if (hit) {
        hit.isStatic = !hit.isStatic;
        hit.vx = 0;
        hit.vy = 0;
        hit.omega = 0;
        recalcBodyMassProperties(hit);
        onSelect({ bodyIds: [hit.id], constraintId: null, annotationId: null });
        onCommitMutation(true);
      }
      return;
    }

    if (activeTool === 'pin' || activeTool === 'weld') {
      const hits = findAllBodiesAt(rawWorld, tol);
      if (hits.length >= 1) {
        const bA = hits[0];
        const bB = hits.length >= 2 ? hits[1] : null;
        const c: PhysicsConstraint = {
          id: nextId(activeTool),
          name: activeTool === 'pin' ? 'Pin Joint' : 'Rigid Joint',
          kind: activeTool,
          bodyAId: bA.id,
          bodyBId: bB ? bB.id : null,
          localA: worldToLocal(bA, rawWorld),
          localB: bB ? worldToLocal(bB, rawWorld) : rawWorld,
          referenceAngle: bB ? bB.angle - bA.angle : -bA.angle,
          enabled: true,
          color: '#1e293b',
        };
        simRef.current.constraints.push(c);
        onSelect({ bodyIds: [], constraintId: c.id, annotationId: null });
        onCommitMutation(true);
      }
      return;
    }

    if (activeTool === 'hslot' || activeTool === 'vslot') {
      const hit = findTopBodyAt(rawWorld, tol);
      if (hit) {
        const c: PhysicsConstraint = {
          id: nextId('slot'),
          name: activeTool === 'hslot' ? 'Horizontal Slot' : 'Vertical Slot',
          kind: 'slot',
          bodyAId: hit.id,
          bodyBId: null,
          localA: worldToLocal(hit, rawWorld),
          localB: rawWorld,
          slotAngle: activeTool === 'hslot' ? 0 : Math.PI / 2,
          slotKeyed: false,
          slotLength: 4.0,
          referenceAngle: hit.angle,
          enabled: true,
          color: '#0f172a',
        };
        simRef.current.constraints.push(c);
        onSelect({ bodyIds: [], constraintId: c.id, annotationId: null });
        onCommitMutation(true);
      }
      return;
    }

    if (activeTool === 'motor') {
      const hits = findAllBodiesAt(rawWorld, tol);
      if (hits.length >= 1) {
        const bA = hits[0];
        const bB = hits.length >= 2 ? hits[1] : null;
        // Also place a pin joint so the motor spins around that point!
        const pin: PhysicsConstraint = {
          id: nextId('pin'),
          name: 'Motor Pivot Pin',
          kind: 'pin',
          bodyAId: bA.id,
          bodyBId: bB ? bB.id : null,
          localA: worldToLocal(bA, rawWorld),
          localB: bB ? worldToLocal(bB, rawWorld) : rawWorld,
          enabled: true,
          color: '#334155',
        };
        const motor: PhysicsConstraint = {
          id: nextId('motor'),
          name: 'Rotary Motor',
          kind: 'motor',
          bodyAId: bA.id,
          bodyBId: bB ? bB.id : null,
          localA: worldToLocal(bA, rawWorld),
          localB: bB ? worldToLocal(bB, rawWorld) : rawWorld,
          motorTargetOmega: 3.0,
          motorMaxTorque: 80,
          enabled: true,
          color: '#dc2626',
        };
        simRef.current.constraints.push(pin, motor);
        onSelect({ bodyIds: [], constraintId: motor.id, annotationId: null });
        onCommitMutation(true);
      }
      return;
    }

    if (activeTool === 'torque') {
      const hit = findTopBodyAt(rawWorld, tol);
      if (hit) {
        const tq: PhysicsConstraint = {
          id: nextId('torque'),
          name: 'Applied Torque',
          kind: 'torque',
          bodyAId: hit.id,
          bodyBId: null,
          localA: { x: 0, y: 0 },
          localB: { x: 0, y: 0 },
          torqueValue: 15,
          enabled: true,
          color: '#dc2626',
        };
        simRef.current.constraints.push(tq);
        onSelect({ bodyIds: [], constraintId: tq.id, annotationId: null });
        onCommitMutation(true);
      }
      return;
    }

    if (activeTool === 'thruster') {
      const hit = findTopBodyAt(rawWorld, tol);
      if (hit) {
        const local = worldToLocal(hit, rawWorld);
        hit.thruster = {
          enabled: true,
          fx: 25,
          fy: 0,
          localX: local.x,
          localY: local.y,
        };
        onSelect({ bodyIds: [hit.id], constraintId: null, annotationId: null });
        onCommitMutation(true);
      }
      return;
    }

    // Two-point drag tools
    if (
      activeTool === 'spring' ||
      activeTool === 'damper' ||
      activeTool === 'rope' ||
      activeTool === 'rod' ||
      activeTool === 'actuator' ||
      activeTool === 'slot' ||
      activeTool === 'force'
    ) {
      const hit = findTopBodyAt(rawWorld, tol);
      dragRef.current = {
        type: 'drawLink',
        linkTool: activeTool,
        startWorld: worldPt,
        currentWorld: worldPt,
        startBodyId: hit ? hit.id : null,
        startLocal: hit ? worldToLocal(hit, rawWorld) : worldPt,
      };
      return;
    }

    // Rotate Tool
    if (activeTool === 'rotate') {
      const hit = findTopBodyAt(rawWorld, tol);
      if (hit) {
        onSelect({ bodyIds: [hit.id], constraintId: null, annotationId: null });
        dragRef.current = {
          type: 'rotateBody',
          bodyId: hit.id,
          startAngle: hit.angle,
          pointerStartAngle: Math.atan2(rawWorld.y - hit.y, rawWorld.x - hit.x),
        };
      }
      return;
    }

    // Select Tool
    // 1. Check resize/rotate handles on currently selected single body
    if (!isRunning && selection.bodyIds.length === 1) {
      const selBody = simRef.current.bodies.find((b) => b.id === selection.bodyIds[0]);
      if (selBody) {
        const handle = hitTestResizeHandle(selBody, sx, sy);
        if (handle === 'rot') {
          dragRef.current = {
            type: 'rotateBody',
            bodyId: selBody.id,
            startAngle: selBody.angle,
            pointerStartAngle: Math.atan2(rawWorld.y - selBody.y, rawWorld.x - selBody.x),
          };
          return;
        }
        if (handle) {
          dragRef.current = {
            type: 'resizeBody',
            bodyId: selBody.id,
            handle,
            startWorld: rawWorld,
            origW: selBody.width,
            origH: selBody.height,
            origR: selBody.radius,
          };
          return;
        }
      }
    }

    // 2. Check bodies
    const hitBody = findTopBodyAt(rawWorld, tol);
    if (hitBody) {
      let nextIds = selection.bodyIds;
      if (e.shiftKey) {
        nextIds = nextIds.includes(hitBody.id)
          ? nextIds.filter((id) => id !== hitBody.id)
          : [...nextIds, hitBody.id];
      } else if (!nextIds.includes(hitBody.id)) {
        nextIds = [hitBody.id];
      }
      onSelect({ bodyIds: nextIds, constraintId: null, annotationId: null });

      if (isRunning) {
        // Smooth physical spring grabber while running
        dragSpringRef.current = {
          bodyId: hitBody.id,
          localPoint: worldToLocal(hitBody, rawWorld),
          targetWorld: rawWorld,
        };
        dragRef.current = { type: 'springGrab', bodyId: hitBody.id };
      } else {
        const initialPos = new Map<string, Vec2>();
        for (const b of simRef.current.bodies) {
          if (nextIds.includes(b.id)) {
            initialPos.set(b.id, { x: b.x, y: b.y });
          }
        }
        dragRef.current = {
          type: 'moveBodies',
          startWorld: rawWorld,
          initialPos,
        };
      }
      return;
    }

    // 3. Check constraints (springs, pins, ropes, etc.)
    const hitConstraint = findConstraintAt(rawWorld, tol);
    if (hitConstraint) {
      onSelect({ bodyIds: [], constraintId: hitConstraint.id, annotationId: null });
      return;
    }

    // 4. Check annotations
    const hitAnn = findAnnotationAt(rawWorld);
    if (hitAnn) {
      onSelect({ bodyIds: [], constraintId: null, annotationId: hitAnn.id });
      return;
    }

    // 5. Empty space -> marquee selection
    onSelect({ bodyIds: [], constraintId: null, annotationId: null });
    dragRef.current = {
      type: 'marquee',
      startWorld: rawWorld,
      currentWorld: rawWorld,
    };
  };

  // Pointer Move
  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const sx = e.clientX - rect.left;
    const sy = e.clientY - rect.top;
    const rawWorld = screenToWorld(sx, sy);
    const worldPt = maybeSnap(rawWorld);

    setHoverWorld(rawWorld);
    onCursorMove(rawWorld);

    const drag = dragRef.current;
    if (drag.type === 'none') return;

    if (drag.type === 'pan') {
      const dx = sx - drag.startScreen.x;
      const dy = sy - drag.startScreen.y;
      cameraRef.current.panX = drag.startPan.x - dx / cameraRef.current.ppm;
      cameraRef.current.panY = drag.startPan.y + dy / cameraRef.current.ppm;
      return;
    }

    if (drag.type === 'springGrab') {
      if (dragSpringRef.current) {
        dragSpringRef.current.targetWorld = rawWorld;
      }
      return;
    }

    if (drag.type === 'moveBodies') {
      const dx = rawWorld.x - drag.startWorld.x;
      const dy = rawWorld.y - drag.startWorld.y;
      for (const b of simRef.current.bodies) {
        const orig = drag.initialPos.get(b.id);
        if (orig) {
          const moved = maybeSnap({ x: orig.x + dx, y: orig.y + dy });
          b.x = moved.x;
          b.y = moved.y;
          b.tracePoints = [];
        }
      }
      return;
    }

    if (drag.type === 'rotateBody') {
      const b = simRef.current.bodies.find((item) => item.id === drag.bodyId);
      if (b) {
        const curAng = Math.atan2(rawWorld.y - b.y, rawWorld.x - b.x);
        b.angle = drag.startAngle + (curAng - drag.pointerStartAngle);
      }
      return;
    }

    if (drag.type === 'resizeBody') {
      const b = simRef.current.bodies.find((item) => item.id === drag.bodyId);
      if (!b) return;
      if (b.shape === 'circle' || b.shape === 'gear' || b.shape === 'pulley') {
        const r = Math.max(0.15, Math.hypot(rawWorld.x - b.x, rawWorld.y - b.y));
        b.radius = Number(r.toFixed(3));
        recalcBodyMassProperties(b);
      } else if (b.shape === 'rect') {
        const localStart = worldToLocal(b, drag.startWorld);
        const localCur = worldToLocal(b, rawWorld);
        const dx = localCur.x - localStart.x;
        const dy = localCur.y - localStart.y;
        const signX = drag.handle.includes('e') ? 1 : -1;
        const signY = drag.handle.includes('n') ? 1 : -1;
        b.width = Math.max(0.2, drag.origW + signX * dx * 2);
        b.height = Math.max(0.2, drag.origH + signY * dy * 2);
        b.vertices = getRectVertices(b.width, b.height);
        recalcBodyMassProperties(b);
      }
      return;
    }

    if (drag.type === 'marquee') {
      drag.currentWorld = rawWorld;
      return;
    }

    if (drag.type === 'drawShape') {
      drag.currentWorld = worldPt;
      return;
    }

    if (drag.type === 'drawLink') {
      drag.currentWorld = worldPt;
      return;
    }
  };

  // Pointer Up
  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (canvas && canvas.hasPointerCapture(e.pointerId)) {
      canvas.releasePointerCapture(e.pointerId);
    }

    const drag = dragRef.current;
    dragRef.current = { type: 'none' };
    dragSpringRef.current = null;

    if (drag.type === 'moveBodies' || drag.type === 'rotateBody' || drag.type === 'resizeBody') {
      onCommitMutation(true);
      return;
    }

    if (drag.type === 'marquee') {
      const minX = Math.min(drag.startWorld.x, drag.currentWorld.x);
      const maxX = Math.max(drag.startWorld.x, drag.currentWorld.x);
      const minY = Math.min(drag.startWorld.y, drag.currentWorld.y);
      const maxY = Math.max(drag.startWorld.y, drag.currentWorld.y);
      if (maxX - minX > 0.08 || maxY - minY > 0.08) {
        const ids = simRef.current.bodies
          .filter((b) => b.x >= minX && b.x <= maxX && b.y >= minY && b.y <= maxY)
          .map((b) => b.id);
        onSelect({ bodyIds: ids, constraintId: null, annotationId: null });
      }
      return;
    }

    if (drag.type === 'drawShape') {
      const sx = drag.startWorld.x;
      const sy = drag.startWorld.y;
      const ex = drag.currentWorld.x;
      const ey = drag.currentWorld.y;
      const dx = ex - sx;
      const dy = ey - sy;

      let newBody: RigidBody | null = null;
      if (drag.shapeTool === 'rect' || drag.shapeTool === 'square') {
        let w = Math.abs(dx);
        let h = Math.abs(dy);
        if (drag.shapeTool === 'square') {
          const side = Math.max(w, h, 0.8);
          w = side;
          h = side;
        } else {
          if (w < 0.25 && h < 0.25) {
            w = 1.6;
            h = 1.0;
          } else {
            w = Math.max(0.25, w);
            h = Math.max(0.25, h);
          }
        }
        const cx = drag.shapeTool === 'square' ? sx + (dx >= 0 ? w / 2 : -w / 2) : (sx + ex) / 2;
        const cy = drag.shapeTool === 'square' ? sy + (dy >= 0 ? h / 2 : -h / 2) : (sy + ey) / 2;
        newBody = createBody({
          shape: 'rect',
          x: cx,
          y: cy,
          width: w,
          height: h,
          name: `${drag.shapeTool === 'square' ? 'Square' : 'Rectangle'} ${simRef.current.bodies.length + 1}`,
        });
      } else {
        const r = Math.max(0.35, Math.hypot(dx, dy) < 0.1 ? 0.65 : Math.hypot(dx, dy));
        newBody = createBody({
          shape: drag.shapeTool,
          x: sx,
          y: sy,
          radius: r,
          collidable: drag.shapeTool === 'circle',
          name: `${drag.shapeTool.charAt(0).toUpperCase() + drag.shapeTool.slice(1)} ${simRef.current.bodies.length + 1}`,
        });
      }

      if (newBody) {
        simRef.current.bodies.push(newBody);
        onSelect({ bodyIds: [newBody.id], constraintId: null, annotationId: null });
        onCommitMutation(true);
      }
      return;
    }

    if (drag.type === 'drawLink') {
      const tol = 12 / cameraRef.current.ppm;
      const endWorld = drag.currentWorld;
      const hitEnd = findTopBodyAt(endWorld, tol);
      const len = vLen(vSub(endWorld, drag.startWorld));

      if (drag.linkTool === 'force') {
        if (drag.startBodyId) {
          const fVec = vSub(endWorld, drag.startWorld);
          const scale = 20;
          const forceC: PhysicsConstraint = {
            id: nextId('force'),
            name: 'Applied Force',
            kind: 'force',
            bodyAId: drag.startBodyId,
            bodyBId: null,
            localA: drag.startLocal,
            localB: { x: 0, y: 0 },
            forceX: Math.abs(fVec.x) < 0.1 && Math.abs(fVec.y) < 0.1 ? 20 : fVec.x * scale,
            forceY: Math.abs(fVec.x) < 0.1 && Math.abs(fVec.y) < 0.1 ? 0 : fVec.y * scale,
            forceFollowBody: false,
            enabled: true,
            color: '#dc2626',
          };
          simRef.current.constraints.push(forceC);
          onSelect({ bodyIds: [], constraintId: forceC.id, annotationId: null });
          onCommitMutation(true);
        }
        return;
      }

      if (drag.linkTool === 'slot') {
        if (drag.startBodyId) {
          const ang = len > 0.1 ? Math.atan2(endWorld.y - drag.startWorld.y, endWorld.x - drag.startWorld.x) : 0;
          const slotC: PhysicsConstraint = {
            id: nextId('slot'),
            name: 'Angled Slot',
            kind: 'slot',
            bodyAId: drag.startBodyId,
            bodyBId: null,
            localA: drag.startLocal,
            localB: drag.startWorld,
            slotAngle: ang,
            slotKeyed: false,
            slotLength: Math.max(3.0, len * 2),
            enabled: true,
            color: '#0f172a',
          };
          simRef.current.constraints.push(slotC);
          onSelect({ bodyIds: [], constraintId: slotC.id, annotationId: null });
          onCommitMutation(true);
        }
        return;
      }

      // Spring, Damper, Rope, Rod, Actuator
      if (len < 0.12 && !drag.startBodyId && !hitEnd) return;

      // For rope: check if a pulley exists near midpoint so rope wraps over it automatically!
      let pulleyId: string | null = null;
      if (drag.linkTool === 'rope') {
        const mid = {
          x: (drag.startWorld.x + endWorld.x) / 2,
          y: (drag.startWorld.y + endWorld.y) / 2,
        };
        const pulley = simRef.current.bodies.find(
          (b) => b.shape === 'pulley' && vLen(vSub(mid, { x: b.x, y: b.y })) <= b.radius * 2.5
        );
        if (pulley) pulleyId = pulley.id;
      }

      const endLocal = hitEnd ? worldToLocal(hitEnd, endWorld) : endWorld;
      const dist = Math.max(0.2, len);
      const c: PhysicsConstraint = {
        id: nextId(drag.linkTool),
        name: drag.linkTool.charAt(0).toUpperCase() + drag.linkTool.slice(1),
        kind: drag.linkTool,
        bodyAId: drag.startBodyId,
        bodyBId: hitEnd ? hitEnd.id : null,
        localA: drag.startLocal,
        localB: endLocal,
        restLength: dist,
        maxLength: dist,
        stiffness: 50,
        damping: drag.linkTool === 'damper' ? 10 : 0.4,
        actuatorMode: 'sine',
        actuatorAmplitude: Math.min(0.8, dist * 0.35),
        actuatorFrequency: 3.0,
        actuatorVelocity: 0.4,
        pulleyBodyId: pulleyId,
        enabled: true,
        color:
          drag.linkTool === 'spring'
            ? '#2563eb'
            : drag.linkTool === 'rope'
            ? '#92400e'
            : drag.linkTool === 'damper'
            ? '#475569'
            : '#1e293b',
      };
      simRef.current.constraints.push(c);
      onSelect({ bodyIds: [], constraintId: c.id, annotationId: null });
      onCommitMutation(true);
    }
  };

  // Double-click finishes polygon or switches to Select
  const handleDoubleClick = () => {
    if (activeTool === 'polygon') {
      finishPolygon();
      onChangeTool('select');
    }
  };

  // Wheel Zoom toward mouse pointer
  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const sx = e.clientX - rect.left;
    const sy = e.clientY - rect.top;
    const before = screenToWorld(sx, sy);

    const factor = e.deltaY < 0 ? 1.12 : 0.89;
    const cam = cameraRef.current;
    const newPpm = Math.max(12, Math.min(240, cam.ppm * factor));
    cam.ppm = newPpm;
    cam.panX = before.x - (sx - canvasSize.w / 2) / newPpm;
    cam.panY = before.y + (sy - canvasSize.h / 2) / newPpm;
  };

  // 60fps Canvas Render Loop
  useEffect(() => {
    let rafId = 0;

    const render = () => {
      const canvas = canvasRef.current;
      if (canvas) {
        const dpr = window.devicePixelRatio || 1;
        const w = canvasSize.w;
        const h = canvasSize.h;
        if (canvas.width !== Math.floor(w * dpr) || canvas.height !== Math.floor(h * dpr)) {
          canvas.width = Math.floor(w * dpr);
          canvas.height = Math.floor(h * dpr);
        }
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
          drawScene(ctx, w, h);
        }
      }
      rafId = requestAnimationFrame(render);
    };

    const drawScene = (ctx: CanvasRenderingContext2D, w: number, h: number) => {
      const state = simRef.current;
      const cam = cameraRef.current;
      const ppm = cam.ppm;
      const toS = (wx: number, wy: number) => ({
        x: w / 2 + (wx - cam.panX) * ppm,
        y: h / 2 - (wy - cam.panY) * ppm,
      });

      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, w, h);

      // Visible world bounds
      const minWX = cam.panX - w / (2 * ppm);
      const maxWX = cam.panX + w / (2 * ppm);
      const minWY = cam.panY - h / (2 * ppm);
      const maxWY = cam.panY + h / (2 * ppm);

      // 1. Grid
      if (state.world.showGrid) {
        const spacing = Math.max(0.25, state.world.gridSpacing);
        ctx.strokeStyle = '#e5e7eb';
        ctx.lineWidth = 1;
        ctx.beginPath();
        const startX = Math.floor(minWX / spacing) * spacing;
        for (let gx = startX; gx <= maxWX; gx += spacing) {
          const sx = toS(gx, 0).x;
          ctx.moveTo(sx, 0);
          ctx.lineTo(sx, h);
        }
        const startY = Math.floor(minWY / spacing) * spacing;
        for (let gy = startY; gy <= maxWY; gy += spacing) {
          const sy = toS(0, gy).y;
          ctx.moveTo(0, sy);
          ctx.lineTo(w, sy);
        }
        ctx.stroke();
      }

      // 2. Origin Axes
      if (state.world.showAxes) {
        const origin = toS(0, 0);
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(0, origin.y);
        ctx.lineTo(w, origin.y);
        ctx.moveTo(origin.x, 0);
        ctx.lineTo(origin.x, h);
        ctx.stroke();

        // Origin tick label
        ctx.fillStyle = '#64748b';
        ctx.font = '10px "IBM Plex Mono", monospace';
        ctx.fillText('(0,0)', origin.x + 4, origin.y - 4);
      }

      // 3. Path Tracks
      if (state.world.showTrackPoints) {
        for (const b of state.bodies) {
          if (b.trackCOM && b.tracePoints.length > 1) {
            ctx.strokeStyle = b.strokeColor;
            ctx.globalAlpha = 0.45;
            ctx.lineWidth = 1.2;
            ctx.beginPath();
            for (let i = 0; i < b.tracePoints.length; i++) {
              const p = toS(b.tracePoints[i].x, b.tracePoints[i].y);
              if (i === 0) ctx.moveTo(p.x, p.y);
              else ctx.lineTo(p.x, p.y);
            }
            ctx.stroke();
            ctx.globalAlpha = 1;

            ctx.fillStyle = b.strokeColor;
            for (let i = 0; i < b.tracePoints.length; i += 4) {
              const p = toS(b.tracePoints[i].x, b.tracePoints[i].y);
              ctx.fillRect(p.x - 1.5, p.y - 1.5, 3, 3);
            }
          }
        }
      }

      const bodyMap = new Map(state.bodies.map((b) => [b.id, b]));

      // 4. Slot rails (behind bodies)
      for (const c of state.constraints) {
        if (c.kind === 'slot') {
          drawConstraint(ctx, c, bodyMap, toS, ppm, selection.constraintId === c.id, state.time);
        }
      }

      // 5. Rigid Bodies
      for (const b of state.bodies) {
        const isSel = selection.bodyIds.includes(b.id);
        drawBody(ctx, b, toS, ppm, isSel, state.world.showCOM);
      }

      // 6. Foreground Constraints (Springs, Dampers, Ropes, Rods, Actuators, Pins, Motors, Forces)
      for (const c of state.constraints) {
        if (c.kind !== 'slot') {
          drawConstraint(ctx, c, bodyMap, toS, ppm, selection.constraintId === c.id, state.time);
        }
      }

      // 7. Vectors (Velocity, Acceleration, Force, Gravity)
      const vScale = state.world.vectorScale;
      for (const b of state.bodies) {
        const origin = toS(b.x, b.y);
        if (state.world.showVectors.velocity) {
          drawVectorArrow(ctx, origin, b.vx * vScale * ppm, -b.vy * vScale * ppm, '#2563eb', 'V');
        }
        if (state.world.showVectors.acceleration) {
          drawVectorArrow(ctx, origin, b.ax * vScale * ppm * 0.5, -b.ay * vScale * ppm * 0.5, '#16a34a', 'A');
        }
        if (state.world.showVectors.force && !b.isStatic) {
          const fx = b.mass * b.ax;
          const fy = b.mass * b.ay;
          drawVectorArrow(ctx, origin, fx * vScale * ppm * 0.08, -fy * vScale * ppm * 0.08, '#dc2626', 'F');
        }
        if (state.world.showVectors.gravity && !b.isStatic && state.world.gravityMode === 'vertical') {
          drawVectorArrow(
            ctx,
            origin,
            b.mass * state.world.gx * vScale * ppm * 0.08,
            -b.mass * state.world.gy * vScale * ppm * 0.08,
            '#7c3aed',
            'Fg'
          );
        }
      }

      // 8. Text Annotations
      for (const ann of state.annotations) {
        const p = toS(ann.x, ann.y);
        ctx.font = `500 ${ann.fontSize}px "IBM Plex Sans", sans-serif`;
        ctx.fillStyle = ann.color;
        ctx.fillText(ann.text, p.x, p.y);
        if (selection.annotationId === ann.id) {
          const m = ctx.measureText(ann.text);
          ctx.strokeStyle = '#2563eb';
          ctx.lineWidth = 1;
          ctx.strokeRect(p.x - 4, p.y - ann.fontSize, m.width + 8, ann.fontSize + 6);
        }
      }

      // 9. Selection Resize / Rotate Handles (when single body selected & stopped)
      if (!isRunning && selection.bodyIds.length === 1) {
        const sel = bodyMap.get(selection.bodyIds[0]);
        if (sel && sel.shape !== 'point') {
          drawSelectionHandles(ctx, sel, toS, ppm);
        }
      }

      // 10. Active Drag / Draw Previews
      const drag = dragRef.current;
      if (drag.type === 'marquee') {
        const a = toS(drag.startWorld.x, drag.startWorld.y);
        const b = toS(drag.currentWorld.x, drag.currentWorld.y);
        ctx.strokeStyle = '#2563eb';
        ctx.fillStyle = 'rgba(37, 99, 235, 0.1)';
        ctx.lineWidth = 1;
        ctx.setLineDash([4, 3]);
        ctx.fillRect(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.abs(b.x - a.x), Math.abs(b.y - a.y));
        ctx.strokeRect(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.abs(b.x - a.x), Math.abs(b.y - a.y));
        ctx.setLineDash([]);
      } else if (drag.type === 'drawShape') {
        const a = toS(drag.startWorld.x, drag.startWorld.y);
        const b = toS(drag.currentWorld.x, drag.currentWorld.y);
        ctx.strokeStyle = '#2563eb';
        ctx.fillStyle = 'rgba(147, 197, 253, 0.35)';
        ctx.lineWidth = 1.5;
        if (drag.shapeTool === 'circle' || drag.shapeTool === 'gear' || drag.shapeTool === 'pulley') {
          const rPx = Math.hypot(b.x - a.x, b.y - a.y);
          ctx.beginPath();
          ctx.arc(a.x, a.y, rPx, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
        } else {
          ctx.fillRect(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.abs(b.x - a.x), Math.abs(b.y - a.y));
          ctx.strokeRect(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.abs(b.x - a.x), Math.abs(b.y - a.y));
        }
      } else if (drag.type === 'drawLink') {
        const a = toS(drag.startWorld.x, drag.startWorld.y);
        const b = toS(drag.currentWorld.x, drag.currentWorld.y);
        ctx.strokeStyle = '#2563eb';
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 4]);
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // Polygon in-progress preview
      if (activeTool === 'polygon' && polyPointsRef.current.length > 0) {
        const pts = polyPointsRef.current;
        ctx.strokeStyle = '#2563eb';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        for (let i = 0; i < pts.length; i++) {
          const p = toS(pts[i].x, pts[i].y);
          if (i === 0) ctx.moveTo(p.x, p.y);
          else ctx.lineTo(p.x, p.y);
        }
        const curS = toS(hoverWorld.x, hoverWorld.y);
        ctx.lineTo(curS.x, curS.y);
        ctx.stroke();

        ctx.fillStyle = '#2563eb';
        for (const pt of pts) {
          const p = toS(pt.x, pt.y);
          ctx.fillRect(p.x - 3, p.y - 3, 6, 6);
        }
      }

      // Live spring grab line while running
      if (dragSpringRef.current) {
        const gb = bodyMap.get(dragSpringRef.current.bodyId);
        if (gb) {
          const pBody = localToWorld(gb, dragSpringRef.current.localPoint);
          const s1 = toS(pBody.x, pBody.y);
          const s2 = toS(dragSpringRef.current.targetWorld.x, dragSpringRef.current.targetWorld.y);
          ctx.strokeStyle = '#ef4444';
          ctx.lineWidth = 2;
          ctx.setLineDash([4, 3]);
          ctx.beginPath();
          ctx.moveTo(s1.x, s1.y);
          ctx.lineTo(s2.x, s2.y);
          ctx.stroke();
          ctx.setLineDash([]);
        }
      }
    };

    rafId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(rafId);
  }, [activeTool, canvasSize, cameraRef, dragSpringRef, hoverWorld, isRunning, renderVersion, selection, simRef]);

  // Cursor style
  const cursorClass =
    activeTool === 'pan'
      ? 'cursor-grab active:cursor-grabbing'
      : activeTool === 'zoom'
      ? 'cursor-zoom-in'
      : activeTool === 'select'
      ? 'cursor-default'
      : 'cursor-crosshair';

  return (
    <div ref={containerRef} className="relative flex-1 h-full overflow-hidden bg-white select-none">
      {/* Top Ruler */}
      {showRulers && (
        <MetricRuler
          orientation="horizontal"
          length={canvasSize.w}
          offsetLeft={rulerOffset}
          pan={cameraRef.current.panX}
          ppm={cameraRef.current.ppm}
          cursorVal={hoverWorld.x}
        />
      )}

      {/* Left Ruler */}
      {showRulers && (
        <MetricRuler
          orientation="vertical"
          length={canvasSize.h}
          offsetTop={rulerOffset}
          pan={cameraRef.current.panY}
          ppm={cameraRef.current.ppm}
          cursorVal={hoverWorld.y}
        />
      )}

      {/* Corner square where rulers meet */}
      {showRulers && (
        <div className="absolute top-0 left-0 w-[22px] h-[22px] bg-[#e2e8f0] border-r border-b border-[#94a3b8] z-20 flex items-center justify-center text-[9px] font-mono-num text-[#475569]">
          m
        </div>
      )}

      <canvas
        ref={canvasRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        onDoubleClick={handleDoubleClick}
        onWheel={handleWheel}
        style={{
          touchAction: 'none',
          left: rulerOffset,
          top: rulerOffset,
          width: `calc(100% - ${rulerOffset}px)`,
          height: `calc(100% - ${rulerOffset}px)`,
        }}
        className={`absolute block ${cursorClass}`}
      />

      {activeTool === 'polygon' && polyCount > 0 && (
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 bg-[#1e293b] text-white text-[12px] px-3 py-1 rounded shadow z-20 pointer-events-none">
          Polygon: {polyCount} vertices — Double-click or press Enter to close (Esc to cancel)
        </div>
      )}
    </div>
  );
};

// Dynamic Metric Ruler Component
const MetricRuler: React.FC<{
  orientation: 'horizontal' | 'vertical';
  length: number;
  offsetLeft?: number;
  offsetTop?: number;
  pan: number;
  ppm: number;
  cursorVal: number;
}> = ({ orientation, length, offsetLeft = 0, offsetTop = 0, pan, ppm, cursorVal }) => {
  const step = ppm > 90 ? 0.5 : ppm > 35 ? 1 : 2;
  const ticks: Array<{ pos: number; label: string; major: boolean }> = [];

  if (orientation === 'horizontal') {
    const minW = pan - length / (2 * ppm);
    const maxW = pan + length / (2 * ppm);
    const start = Math.floor(minW / (step / 2)) * (step / 2);
    for (let v = start; v <= maxW; v += step / 2) {
      const px = length / 2 + (v - pan) * ppm;
      const major = Math.abs(Math.round(v / step) * step - v) < 1e-4;
      ticks.push({ pos: px, label: major ? `${Number(v.toFixed(1))}` : '', major });
    }
    const cursorPx = length / 2 + (cursorVal - pan) * ppm;
    return (
      <div
        style={{ left: offsetLeft, width: `calc(100% - ${offsetLeft}px)` }}
        className="absolute top-0 h-[22px] bg-[#f1f5f9] border-b border-[#94a3b8] overflow-hidden z-10 pointer-events-none"
      >
        {ticks.map((t, idx) => (
          <div
            key={idx}
            style={{ left: t.pos }}
            className="absolute bottom-0 flex flex-col items-start"
          >
            {t.label && (
              <span className="text-[9px] text-[#475569] font-mono-num pl-0.5 leading-none mb-0.5">
                {t.label}
              </span>
            )}
            <div className={`w-[1px] bg-[#64748b] ${t.major ? 'h-2.5' : 'h-1.5'}`} />
          </div>
        ))}
        <div
          style={{ left: cursorPx }}
          className="absolute top-0 bottom-0 w-[1px] bg-[#2563eb]"
        />
      </div>
    );
  }

  // Vertical (Y-up)
  const minW = pan - length / (2 * ppm);
  const maxW = pan + length / (2 * ppm);
  const start = Math.floor(minW / (step / 2)) * (step / 2);
  for (let v = start; v <= maxW; v += step / 2) {
    const py = length / 2 - (v - pan) * ppm;
    const major = Math.abs(Math.round(v / step) * step - v) < 1e-4;
    ticks.push({ pos: py, label: major ? `${Number(v.toFixed(1))}` : '', major });
  }
  const cursorPy = length / 2 - (cursorVal - pan) * ppm;
  return (
    <div
      style={{ top: offsetTop, height: `calc(100% - ${offsetTop}px)` }}
      className="absolute left-0 w-[22px] bg-[#f1f5f9] border-r border-[#94a3b8] overflow-hidden z-10 pointer-events-none"
    >
      {ticks.map((t, idx) => (
        <div key={idx} style={{ top: t.pos }} className="absolute right-0 flex items-center">
          {t.label && (
            <span className="text-[8px] text-[#475569] font-mono-num pr-0.5 leading-none">
              {t.label}
            </span>
          )}
          <div className={`h-[1px] bg-[#64748b] ${t.major ? 'w-2' : 'w-1'}`} />
        </div>
      ))}
      <div
        style={{ top: cursorPy }}
        className="absolute left-0 right-0 h-[1px] bg-[#2563eb]"
      />
    </div>
  );
};

// Drawing Helpers
function drawBody(
  ctx: CanvasRenderingContext2D,
  b: RigidBody,
  toS: (x: number, y: number) => Vec2,
  ppm: number,
  isSel: boolean,
  showGlobalCOM: boolean
) {
  const c = toS(b.x, b.y);
  ctx.save();
  ctx.translate(c.x, c.y);
  ctx.rotate(-b.angle);

  ctx.fillStyle = b.fillColor;
  ctx.strokeStyle = isSel ? '#2563eb' : b.strokeColor;
  ctx.lineWidth = isSel ? 2.2 : 1.5;

  if (b.shape === 'point') {
    ctx.beginPath();
    ctx.arc(0, 0, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.restore();
    return;
  }

  if (b.shape === 'circle') {
    const r = b.radius * ppm;
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    // Orientation spoke line
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(r, 0);
    ctx.strokeStyle = isSel ? '#2563eb' : 'rgba(30,41,59,0.45)';
    ctx.lineWidth = 1.2;
    ctx.stroke();
  } else if (b.shape === 'pulley') {
    const r = b.radius * ppm;
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    // Inner groove & spokes
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.78, 0, Math.PI * 2);
    ctx.stroke();
    for (let i = 0; i < 4; i++) {
      const ang = (i * Math.PI) / 2;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(Math.cos(ang) * r * 0.78, Math.sin(ang) * r * 0.78);
      ctx.stroke();
    }
    ctx.beginPath();
    ctx.arc(0, 0, Math.max(3, r * 0.14), 0, Math.PI * 2);
    ctx.fillStyle = '#334155';
    ctx.fill();
  } else if (b.shape === 'gear') {
    const r = b.radius * ppm;
    const teeth = Math.max(6, b.teeth || 12);
    const outerR = r * 1.1;
    const innerR = r * 0.9;
    ctx.beginPath();
    for (let i = 0; i < teeth; i++) {
      const a0 = (i / teeth) * Math.PI * 2;
      const a1 = ((i + 0.25) / teeth) * Math.PI * 2;
      const a2 = ((i + 0.5) / teeth) * Math.PI * 2;
      const a3 = ((i + 0.75) / teeth) * Math.PI * 2;
      if (i === 0) ctx.moveTo(Math.cos(a0) * innerR, Math.sin(a0) * innerR);
      else ctx.lineTo(Math.cos(a0) * innerR, Math.sin(a0) * innerR);
      ctx.lineTo(Math.cos(a1) * outerR, Math.sin(a1) * outerR);
      ctx.lineTo(Math.cos(a2) * outerR, Math.sin(a2) * outerR);
      ctx.lineTo(Math.cos(a3) * innerR, Math.sin(a3) * innerR);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    // Hub
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.28, 0, Math.PI * 2);
    ctx.fillStyle = '#f8fafc';
    ctx.fill();
    ctx.stroke();
    // Spoke
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(innerR * 0.85, 0);
    ctx.stroke();
  } else if (b.shape === 'rect') {
    const w = b.width * ppm;
    const h = b.height * ppm;
    ctx.fillRect(-w / 2, -h / 2, w, h);
    ctx.strokeRect(-w / 2, -h / 2, w, h);
  } else if (b.shape === 'polygon' && b.vertices.length >= 3) {
    ctx.beginPath();
    for (let i = 0; i < b.vertices.length; i++) {
      const vx = b.vertices[i].x * ppm;
      const vy = -b.vertices[i].y * ppm;
      if (i === 0) ctx.moveTo(vx, vy);
      else ctx.lineTo(vx, vy);
    }
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  // Anchor X-pin icon for static bodies
  if (b.isStatic) {
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(-5, -5);
    ctx.lineTo(5, 5);
    ctx.moveTo(5, -5);
    ctx.lineTo(-5, 5);
    ctx.stroke();
  }

  // Center of Mass crosshair symbol
  if (showGlobalCOM && b.showCOM && !b.isStatic) {
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(0, 0, 4, 0, Math.PI * 2);
    ctx.moveTo(-6, 0);
    ctx.lineTo(6, 0);
    ctx.moveTo(0, -6);
    ctx.lineTo(0, 6);
    ctx.stroke();
  }

  // Thruster visual nozzle
  if (b.thruster && b.thruster.enabled) {
    const tx = b.thruster.localX * ppm;
    const ty = -b.thruster.localY * ppm;
    const ang = Math.atan2(-b.thruster.fy, b.thruster.fx);
    ctx.save();
    ctx.translate(tx, ty);
    ctx.rotate(ang);
    ctx.fillStyle = '#f97316';
    ctx.beginPath();
    ctx.moveTo(-14, 0);
    ctx.lineTo(-4, -5);
    ctx.lineTo(-4, 5);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  ctx.restore();

  if (b.showName) {
    ctx.fillStyle = '#1e293b';
    ctx.font = '11px "IBM Plex Sans", sans-serif';
    ctx.fillText(b.name, c.x + 8, c.y - 8);
  }
}

function drawConstraint(
  ctx: CanvasRenderingContext2D,
  c: PhysicsConstraint,
  bodyMap: Map<string, RigidBody>,
  toS: (x: number, y: number) => Vec2,
  ppm: number,
  isSel: boolean,
  time: number
) {
  const bA = c.bodyAId ? bodyMap.get(c.bodyAId) ?? null : null;
  const bB = c.bodyBId ? bodyMap.get(c.bodyBId) ?? null : null;
  const pAW = bA ? localToWorld(bA, c.localA) : c.localA;
  const pBW = bB ? localToWorld(bB, c.localB) : c.localB;
  const sA = toS(pAW.x, pAW.y);
  const sB = toS(pBW.x, pBW.y);

  ctx.save();
  const baseColor = isSel ? '#2563eb' : c.color;
  ctx.strokeStyle = baseColor;
  ctx.fillStyle = baseColor;
  ctx.lineWidth = isSel ? 2.5 : 1.7;

  if (c.kind === 'spring') {
    const dx = sB.x - sA.x;
    const dy = sB.y - sA.y;
    const dist = Math.hypot(dx, dy);
    if (dist > 2) {
      const ux = dx / dist;
      const uy = dy / dist;
      const px = -uy;
      const py = ux;
      const coils = 10;
      const amp = 7;
      ctx.beginPath();
      ctx.moveTo(sA.x, sA.y);
      const lead = Math.min(12, dist * 0.15);
      ctx.lineTo(sA.x + ux * lead, sA.y + uy * lead);
      const bodyLen = dist - 2 * lead;
      for (let i = 1; i < coils * 2; i++) {
        const t = i / (coils * 2);
        const side = i % 2 === 0 ? -amp : amp;
        const bx = sA.x + ux * (lead + t * bodyLen) + px * side;
        const by = sA.y + uy * (lead + t * bodyLen) + py * side;
        ctx.lineTo(bx, by);
      }
      ctx.lineTo(sB.x - ux * lead, sB.y - uy * lead);
      ctx.lineTo(sB.x, sB.y);
      ctx.stroke();
    }
    drawEndDots(ctx, sA, sB);
  } else if (c.kind === 'damper') {
    const dx = sB.x - sA.x;
    const dy = sB.y - sA.y;
    const dist = Math.hypot(dx, dy) || 1;
    const ux = dx / dist;
    const uy = dy / dist;
    const px = -uy;
    const py = ux;
    const midX = (sA.x + sB.x) / 2;
    const midY = (sA.y + sB.y) / 2;

    // Rod from A to piston
    ctx.beginPath();
    ctx.moveTo(sA.x, sA.y);
    ctx.lineTo(midX, midY);
    ctx.stroke();
    // Piston plate
    ctx.beginPath();
    ctx.moveTo(midX + px * 6, midY + py * 6);
    ctx.lineTo(midX - px * 6, midY - py * 6);
    ctx.stroke();
    // Cylinder around mid
    ctx.beginPath();
    ctx.moveTo(midX - ux * 12 + px * 8, midY - uy * 12 + py * 8);
    ctx.lineTo(midX + ux * 12 + px * 8, midY + uy * 12 + py * 8);
    ctx.lineTo(midX + ux * 12 - px * 8, midY + uy * 12 - py * 8);
    ctx.lineTo(midX - ux * 12 - px * 8, midY - uy * 12 - py * 8);
    ctx.stroke();
    // Rod from cylinder to B
    ctx.beginPath();
    ctx.moveTo(midX + ux * 12, midY + uy * 12);
    ctx.lineTo(sB.x, sB.y);
    ctx.stroke();
    drawEndDots(ctx, sA, sB);
  } else if (c.kind === 'rope') {
    const pulley = c.pulleyBodyId ? bodyMap.get(c.pulleyBodyId) : null;
    if (pulley) {
      const cP = toS(pulley.x, pulley.y);
      const rPx = pulley.radius * ppm;
      const sideA = pAW.x <= pulley.x ? -1 : 1;
      const sideB = pBW.x <= pulley.x ? -1 : 1;
      ctx.beginPath();
      ctx.moveTo(sA.x, sA.y);
      ctx.lineTo(cP.x + sideA * rPx, cP.y);
      ctx.arc(cP.x, cP.y, rPx, Math.PI, 0, false);
      ctx.moveTo(cP.x + sideB * rPx, cP.y);
      ctx.lineTo(sB.x, sB.y);
      ctx.stroke();
    } else {
      const curLen = vLen(vSub(pBW, pAW));
      const maxLen = c.maxLength ?? c.restLength ?? curLen;
      if (curLen < maxLen - 0.03) {
        // Slack curve
        const midX = (sA.x + sB.x) / 2;
        const sag = Math.min(40, (maxLen - curLen) * ppm * 0.6);
        const midY = (sA.y + sB.y) / 2 + sag;
        ctx.beginPath();
        ctx.moveTo(sA.x, sA.y);
        ctx.quadraticCurveTo(midX, midY, sB.x, sB.y);
        ctx.stroke();
      } else {
        ctx.beginPath();
        ctx.moveTo(sA.x, sA.y);
        ctx.lineTo(sB.x, sB.y);
        ctx.stroke();
      }
    }
    drawEndDots(ctx, sA, sB);
  } else if (c.kind === 'rod' || c.kind === 'actuator') {
    ctx.lineWidth = c.kind === 'actuator' ? 4 : 2.5;
    ctx.beginPath();
    ctx.moveTo(sA.x, sA.y);
    ctx.lineTo(sB.x, sB.y);
    ctx.stroke();
    if (c.kind === 'actuator') {
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 7;
      ctx.beginPath();
      ctx.moveTo(sA.x, sA.y);
      ctx.lineTo((sA.x + sB.x) / 2, (sA.y + sB.y) / 2);
      ctx.stroke();
    }
    drawEndDots(ctx, sA, sB);
  } else if (c.kind === 'pin') {
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(sA.x, sA.y, 4.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = baseColor;
    ctx.beginPath();
    ctx.arc(sA.x, sA.y, 1.8, 0, Math.PI * 2);
    ctx.fill();
  } else if (c.kind === 'weld') {
    ctx.strokeRect(sA.x - 5, sA.y - 5, 10, 10);
    ctx.beginPath();
    ctx.moveTo(sA.x - 4, sA.y - 4);
    ctx.lineTo(sA.x + 4, sA.y + 4);
    ctx.moveTo(sA.x + 4, sA.y - 4);
    ctx.lineTo(sA.x - 4, sA.y + 4);
    ctx.stroke();
  } else if (c.kind === 'slot') {
    const ang = (bB ? bB.angle : 0) + (c.slotAngle ?? 0);
    const halfLen = ((c.slotLength ?? 3.5) * ppm) / 2;
    const dx = Math.cos(-ang) * halfLen;
    const dy = Math.sin(-ang) * halfLen;
    ctx.strokeStyle = isSel ? '#2563eb' : '#cbd5e1';
    ctx.lineWidth = 6;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(sB.x - dx, sB.y - dy);
    ctx.lineTo(sB.x + dx, sB.y + dy);
    ctx.stroke();
    ctx.strokeStyle = baseColor;
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(sB.x - dx, sB.y - dy);
    ctx.lineTo(sB.x + dx, sB.y + dy);
    ctx.stroke();
    // Slider pin
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(sA.x, sA.y, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  } else if (c.kind === 'motor') {
    ctx.beginPath();
    ctx.arc(sA.x, sA.y, 11, 0, Math.PI * 1.5);
    ctx.stroke();
    const spin = time * (c.motorTargetOmega ?? 3);
    ctx.beginPath();
    ctx.arc(sA.x, sA.y, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(sA.x, sA.y);
    ctx.lineTo(sA.x + Math.cos(-spin) * 10, sA.y + Math.sin(-spin) * 10);
    ctx.stroke();
  } else if (c.kind === 'force') {
    const rawF = { x: c.forceX ?? 0, y: c.forceY ?? 0 };
    const f = c.forceFollowBody && bA ? {
      x: rawF.x * Math.cos(bA.angle) - rawF.y * Math.sin(bA.angle),
      y: rawF.x * Math.sin(bA.angle) + rawF.y * Math.cos(bA.angle),
    } : rawF;
    drawVectorArrow(ctx, sA, f.x * 2, -f.y * 2, baseColor, `${Math.hypot(f.x, f.y).toFixed(0)}N`);
  } else if (c.kind === 'torque') {
    ctx.beginPath();
    ctx.arc(sA.x, sA.y, 16, 0.2, Math.PI * 1.6);
    ctx.stroke();
  }

  ctx.restore();
}

function drawEndDots(ctx: CanvasRenderingContext2D, a: Vec2, b: Vec2) {
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(a.x, a.y, 3, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(b.x, b.y, 3, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
}

function drawVectorArrow(
  ctx: CanvasRenderingContext2D,
  origin: Vec2,
  dx: number,
  dy: number,
  color: string,
  label?: string
) {
  const len = Math.hypot(dx, dy);
  if (len < 3) return;
  const capped = Math.min(len, 180);
  const ux = dx / len;
  const uy = dy / len;
  const tipX = origin.x + ux * capped;
  const tipY = origin.y + uy * capped;

  ctx.save();
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(origin.x, origin.y);
  ctx.lineTo(tipX, tipY);
  ctx.stroke();

  const head = 7;
  const ang = Math.atan2(uy, ux);
  ctx.beginPath();
  ctx.moveTo(tipX, tipY);
  ctx.lineTo(tipX - head * Math.cos(ang - 0.4), tipY - head * Math.sin(ang - 0.4));
  ctx.lineTo(tipX - head * Math.cos(ang + 0.4), tipY - head * Math.sin(ang + 0.4));
  ctx.closePath();
  ctx.fill();

  if (label) {
    ctx.font = 'bold 10px "IBM Plex Mono", monospace';
    ctx.fillText(label, tipX + 4, tipY - 4);
  }
  ctx.restore();
}

function drawSelectionHandles(
  ctx: CanvasRenderingContext2D,
  b: RigidBody,
  toS: (x: number, y: number) => Vec2,
  ppm: number
) {
  const c = toS(b.x, b.y);
  ctx.save();
  ctx.translate(c.x, c.y);
  ctx.rotate(-b.angle);

  let hw = b.radius * ppm;
  let hh = b.radius * ppm;
  if (b.shape === 'rect') {
    hw = (b.width * ppm) / 2;
    hh = (b.height * ppm) / 2;
  }

  ctx.strokeStyle = '#2563eb';
  ctx.lineWidth = 1;
  ctx.setLineDash([3, 3]);
  ctx.strokeRect(-hw, -hh, hw * 2, hh * 2);
  ctx.setLineDash([]);

  // Rotate stalk
  ctx.beginPath();
  ctx.moveTo(0, -hh);
  ctx.lineTo(0, -hh - 22);
  ctx.stroke();
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(0, -hh - 22, 4.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Corner/cardinal square handles
  const pts =
    b.shape === 'rect'
      ? [
          { x: -hw, y: -hh },
          { x: hw, y: -hh },
          { x: hw, y: hh },
          { x: -hw, y: hh },
        ]
      : [
          { x: hw, y: 0 },
          { x: -hw, y: 0 },
          { x: 0, y: -hh },
          { x: 0, y: hh },
        ];
  for (const p of pts) {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(p.x - 3.5, p.y - 3.5, 7, 7);
    ctx.strokeRect(p.x - 3.5, p.y - 3.5, 7, 7);
  }
  ctx.restore();
}
